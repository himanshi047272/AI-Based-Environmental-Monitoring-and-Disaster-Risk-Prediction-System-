# Data-quality report

## rainfall

- **rows_loaded**: 3577399
- **date_format**: %Y-%m-%d
- **invalid_dates**: 0
- **invalid_codes**: 0
- **invalid_rainfall_values_set_nan**: 0
- **duplicate_district_days_rows**: 6902
- **ambiguous_district_codes**: [9]
- **ambiguous_code_detail**: {9: {'district_names': ['Leh Ladakh'], 'state_codes': [37], 'conflicting_day_fraction': 0.6063960639606396}}
- **rows_excluded_ambiguous_codes**: 9142
- **conflicting_rows_in_non_ambiguous_codes**: 0
- **duplicate_rows_removed**: 0
- **rows_clean**: 3568257
- **rows_rejected**: 9142
- **date_min**: 2009-01-01
- **date_max**: 2024-07-31
- **n_districts**: 627
- **n_states**: 36
- **missing_values**: {'actual': 139717, 'rfs': 41642, 'normal': 656513, 'deviation': 1136490}
- **insufficient_history_districts**: [12, 553, 602, 603, 624, 632]
- **n_insufficient_history**: 6
- **encoding**: utf-8
- **malformed_rows**: 0

## flood_inventory

- **rows_loaded**: 6876
- **date_format**: %d-%m-%Y %H:%M
- **invalid_start_dates**: 0
- **invalid_end_dates**: 0
- **missing_or_invalid_start_date**: 20
- **end_missing_or_before_start**: 17
- **exact_duplicate_events_removed**: 50
- **duplicate_uei**: 0
- **events_clean**: 6806
- **date_min**: 1967-07-02
- **date_max**: 2023-09-12
- **events_without_district_codes**: 306
- **events_without_state_codes**: 258
- **invalid_code_tokens**: 726
- **events_with_over_50_districts**: 34
- **events_longer_than_30_days**: 102
- **encoding**: utf-8
- **malformed_rows**: 0

## district_matching

- **events_total**: 6806
- **events_with_at_least_one_match**: 6154
- **events_unmatched**: 652
- **event_district_pairs_matched**: 20487
- **pairs_by_source**: {'lgd_code': 20357, 'name_fallback': 130}
- **token_status_counts**: {'matched': 20545, 'invalid_code': 1576, 'state_mismatch': 1362, 'unmatched_name': 667, 'matched_name_fallback': 130, 'ambiguous_code': 5}
- **invalid_codes_sample**: [2, 3, 8, 10, 11, 13, 306, 620, 621, 622, 623, 625, 626, 627, 640, 642, 644, 646, 647, 649, 650, 651, 652, 653, 654, 655, 656, 658, 659, 660, 662, 663, 665, 666, 667, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 680, 681, 682, 683, 684]
- **n_invalid_codes_unique**: 97
- **rainfall_districts_total**: 627
- **rainfall_districts_with_any_event**: 606
- **one_to_many_events_matching_over_50_districts**: 27

## labels

- **definition**: label_h = recorded flood-episode onset within (t, t+h] days; episodes merged when overlapping/adjacent; in-event rows excluded; unknown-label tail excluded; absence of a record is NOT confirmed flood-free
- **episodes**: 5723
- **inventory_last_onset**: 2023-09-10
- **rainfall_range**: ['2009-01-01', '2024-07-31']
- **rows_model_frame**: 3159833
- **positives_by_horizon**: {'h1': 5576, 'h2': 10956, 'h3': 16226}
- **positive_rate_primary**: 0.00513508150588971
- **rows_dropped_incomplete_7d_window**: 19076
- **low_inventory_coverage_states**: ['Ladakh', 'Chandigarh', 'Manipur', 'The Dadra And Nagar Haveli And Daman And Diu', 'Lakshadweep', 'Puducherry', 'Andaman And Nicobar Islands']
- **reporting_surge_years**: [2022]
- **max_active_days**: 30
- **excluded_districts_insufficient_history**: [12, 553, 602, 603, 624, 632]
