"""Presentation layer: themes + HTML snippets. Pure functions (no Streamlit import) so they can be unit-tested.

Visual language follows the supplied references:
  * "Sky" (light)  - pastel teal->peach page, white rounded shell with a navy frame, orange + lime accents, navy info card.
  * "Storm" (dark) - deep blue-grey page, translucent glass cards, cyan / amber accents.
"""
from __future__ import annotations

import html
import math

RISK_COLORS = {"Low": "#2E9E5B", "Moderate": "#F2C94C", "High": "#F2994A", "Very high": "#D64545", "Unavailable": "#B8BEC6"}
RISK_TEXT = {"Low": "#FFFFFF", "Moderate": "#3B3000", "High": "#3A1D00", "Very high": "#FFFFFF", "Unavailable": "#33404D"}

THEMES = {
    "Sky (light)": dict(
        name="light", page="linear-gradient(135deg,#CDE9EC 0%,#E9EFEA 45%,#F8E5DB 100%)", shell="#FFFFFF", frame="6px solid #14213D",
        ink="#14213D", muted="#6B7A8C", card="#F4F6F8", line="#E6EBF0", accent="#FF7A1A", lime="#CFE35B", navy="#14213D",
        navy_ink="#FFFFFF", hero="linear-gradient(135deg,#B7E2E6 0%,#DDEBEA 50%,#F6DDD0 100%)", glass="none", sidebar="#F4F6F8"),
    "Storm (dark)": dict(
        name="dark", page="radial-gradient(1200px 600px at 80% -10%,#2A3F55 0%,#0E1822 60%)", shell="rgba(255,255,255,0.03)",
        frame="1px solid rgba(255,255,255,0.10)", ink="#E8EEF4", muted="#93A4B5", card="rgba(255,255,255,0.06)",
        line="rgba(255,255,255,0.10)", accent="#FFB02E", lime="#9BE15D", navy="#0B1219", navy_ink="#E8EEF4",
        hero="linear-gradient(135deg,rgba(63,208,212,0.22) 0%,rgba(255,255,255,0.05) 60%,rgba(255,176,46,0.16) 100%)",
        glass="blur(10px)", sidebar="rgba(10,18,26,0.85)"),
}


def _one_line(s: str) -> str:
    """Collapse to one line so Markdown never treats indented HTML as a code block."""
    return " ".join(line.strip() for line in s.strip().splitlines() if line.strip())


def esc(x) -> str:
    return html.escape("" if x is None else str(x))


def theme_css(theme_key: str) -> str:
    t = THEMES.get(theme_key, THEMES["Sky (light)"])
    return _one_line_css(f"""
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
:root {{ --ink:{t['ink']}; --muted:{t['muted']}; --card:{t['card']}; --line:{t['line']}; --accent:{t['accent']};
        --lime:{t['lime']}; --navy:{t['navy']}; --navy-ink:{t['navy_ink']}; }}
html, body, [class*="css"], .stApp {{ font-family:'Inter','Segoe UI',system-ui,-apple-system,sans-serif; color:var(--ink); }}
.stApp {{ background:{t['page']}; background-attachment:fixed; }}
header[data-testid="stHeader"] {{ background:transparent; }}
.block-container {{ background:{t['shell']}; border:{t['frame']}; border-radius:32px; padding:1.4rem 2rem 2rem 2rem;
                   max-width:1480px; margin-top:.8rem; margin-bottom:1rem; backdrop-filter:{t['glass']}; }}
section[data-testid="stSidebar"] > div:first-child {{ background:{t['sidebar']}; border-radius:0 28px 28px 0; border-right:1px solid var(--line); }}
h1,h2,h3,h4,h5, label, .stMarkdown p, .stRadio label, .stCheckbox label, [data-testid="stWidgetLabel"] p {{ color:var(--ink) !important; }}
h3 {{ font-weight:650; letter-spacing:-.01em; margin-bottom:.4rem; }}
div[data-testid="stPlotlyChart"] {{ border-radius:24px; overflow:hidden; border:1px solid var(--line); }}
div[data-testid="stDataFrame"] {{ border-radius:18px; overflow:hidden; border:1px solid var(--line); }}
.stButton > button, .stDownloadButton > button {{ border-radius:999px; border:1px solid var(--line); background:var(--card); color:var(--ink);
                    font-weight:600; padding:.45rem 1.1rem; }}
.stButton > button:hover, .stDownloadButton > button:hover {{ border-color:var(--accent); color:var(--accent); }}
.stTextInput input {{ border-radius:999px !important; background:var(--card) !important; color:var(--ink) !important; border:1px solid var(--line) !important; }}
.es-brand {{ display:flex; align-items:center; gap:.7rem; }}
.es-brand .t {{ font-size:1.35rem; font-weight:700; letter-spacing:-.02em; }}
.es-brand .s {{ font-size:.82rem; color:var(--muted); margin-top:-.15rem; }}
.es-pill {{ display:inline-flex; align-items:center; gap:.45rem; border-radius:999px; padding:.42rem .9rem; font-size:.8rem; font-weight:600;
           background:var(--card); border:1px solid var(--line); color:var(--ink); white-space:nowrap; }}
.es-dot {{ width:.55rem; height:.55rem; border-radius:50%; display:inline-block; }}
.es-banner {{ border-radius:18px; padding:.7rem 1rem; font-size:.86rem; margin:.6rem 0 1rem 0; border:1px solid var(--line);
             background:{'#FFF4E5' if t['name']=='light' else 'rgba(255,176,46,0.12)'}; color:var(--ink); }}
.es-card {{ border-radius:26px; padding:1.1rem 1.25rem; background:var(--card); border:1px solid var(--line); height:100%; }}
.es-hero {{ border-radius:28px; padding:1.3rem 1.5rem; background:{t['hero']}; position:relative; overflow:hidden; min-height:520px;
           border:1px solid var(--line); }}
.es-chip {{ display:inline-flex; align-items:center; gap:.4rem; background:#fff; color:#14213D; border-radius:999px; padding:.4rem .9rem;
           font-weight:600; font-size:.88rem; box-shadow:0 1px 3px rgba(20,33,61,.12); }}
.es-big {{ font-size:3.2rem; font-weight:700; letter-spacing:-.03em; line-height:1.05; margin:.2rem 0; }}
.es-sub {{ color:var(--muted); font-size:.85rem; }}
.es-tiles {{ display:flex; gap:.7rem; flex-wrap:wrap; margin-top:1rem; }}
.es-tile {{ border-radius:16px; padding:.7rem 1rem; min-width:112px; font-size:.78rem; }}
.es-tile b {{ display:block; font-size:1.15rem; margin-top:.15rem; }}
.es-lime {{ background:var(--lime); color:#1D2A05; }}
.es-white {{ background:#FFFFFF; color:#14213D; }}
.es-navy {{ background:var(--navy); color:var(--navy-ink); border-radius:26px; padding:1.1rem 1.25rem; position:relative; overflow:hidden; }}
.es-kpi {{ border-radius:22px; padding:.95rem 1.1rem; background:var(--card); border:1px solid var(--line); }}
.es-kpi .v {{ font-size:1.75rem; font-weight:700; letter-spacing:-.02em; }}
.es-kpi .l {{ font-size:.78rem; color:var(--muted); }}
.es-row {{ display:flex; align-items:center; justify-content:space-between; gap:.7rem; background:var(--card); border:1px solid var(--line);
          border-radius:18px; padding:.65rem .9rem; margin-bottom:.55rem; }}
.es-row .n {{ font-weight:600; font-size:.92rem; }} .es-row .m {{ color:var(--muted); font-size:.76rem; }}
.es-badge {{ border-radius:999px; padding:.18rem .6rem; font-size:.74rem; font-weight:700; }}
.es-day {{ text-align:center; flex:1; border-right:1px solid var(--line); padding:.4rem .3rem; }}
.es-day:last-child {{ border-right:none; }}
.es-day .mm {{ font-size:1.45rem; font-weight:700; }} .es-day .d {{ font-size:.78rem; color:var(--muted); }}
.es-lime-card {{ background:var(--lime); color:#1D2A05; border-radius:26px; padding:1.1rem 1.25rem; position:relative; overflow:hidden; min-height:260px; height:100%; }}
.es-cm td {{ padding:.6rem 1rem; text-align:center; font-weight:650; border-radius:12px; }}
.es-small {{ font-size:.76rem; color:var(--muted); }}
@media (max-width: 900px) {{ .block-container {{ padding:1rem; border-radius:20px; }} .es-big {{ font-size:2.3rem; }} .es-hero {{ min-height:auto; }} }}
""")


def _one_line_css(s: str) -> str:
    return "<style>" + " ".join(line.strip() for line in s.strip().splitlines() if line.strip()) + "</style>"


# ------------------------------------------------------------------------------------------- icons
def logo_svg(size: int = 40) -> str:
    return _one_line(f"""<svg width="{size}" height="{size}" viewBox="0 0 64 64" aria-label="EcoShieldAI logo">
<path d="M18 46a12 12 0 0 1-1-24 16 16 0 0 1 30 4 10 10 0 0 1 1 20z" fill="#FF7A1A"/>
<path d="M22 30a10 10 0 0 1 18-3 7 7 0 0 1 4 12H24a5 5 0 0 1-2-9z" fill="#FFB36B"/></svg>""")


def weather_icon_svg(level: str = "Low", size: int = 190) -> str:
    """Soft cloud/sun/rain illustration; amount of rain follows the risk level."""
    drops = {"Low": 0, "Moderate": 2, "High": 4, "Very high": 6, "Unavailable": 0}.get(level, 0)
    sun = '<circle cx="118" cy="42" r="24" fill="#FFC83D"/>' + "".join(
        f'<line x1="{118 + 31 * math.cos(a):.1f}" y1="{42 + 31 * math.sin(a):.1f}" x2="{118 + 40 * math.cos(a):.1f}" '
        f'y2="{42 + 40 * math.sin(a):.1f}" stroke="#FFC83D" stroke-width="5" stroke-linecap="round"/>'
        for a in [i * math.pi / 4 for i in range(8)]) if level in ("Low", "Moderate") else ""
    rain = "".join(f'<rect x="{46 + i * 17}" y="104" width="7" height="16" rx="3.5" fill="#2F6FDE" transform="rotate(18 {49 + i * 17} 112)"/>'
                   for i in range(drops))
    cloud = '#B8CBE9' if level != "Very high" else '#8EA0BD'
    return _one_line(f"""<svg width="{size}" height="{int(size * .8)}" viewBox="0 0 170 136" role="img" aria-label="weather illustration">{sun}
<path d="M42 100a24 24 0 0 1 4-47 34 34 0 0 1 65 9 21 21 0 0 1 3 38z" fill="{cloud}"/>
<path d="M62 100a17 17 0 0 1 3-31 26 26 0 0 1 50 7 16 16 0 0 1 2 24z" fill="#DCE7F8" opacity=".85"/>{rain}</svg>""")


def umbrella_svg(size: int = 150) -> str:
    return _one_line(f"""<svg width="{size}" height="{size}" viewBox="0 0 120 120" aria-hidden="true">
<path d="M12 62a48 48 0 0 1 96 0z" fill="#FF7A1A"/><path d="M60 62v38a8 8 0 0 0 16 0" stroke="#14213D" stroke-width="5" fill="none" stroke-linecap="round"/>
<g stroke="#2F6FDE" stroke-width="4" stroke-linecap="round"><line x1="20" y1="76" x2="14" y2="92"/><line x1="40" y1="84" x2="34" y2="100"/>
<line x1="92" y1="78" x2="86" y2="94"/><line x1="104" y1="90" x2="98" y2="106"/></g></svg>""")


# ----------------------------------------------------------------------------------------- snippets
def risk_badge(cat: str) -> str:
    return (f'<span class="es-badge" style="background:{RISK_COLORS.get(cat, "#B8BEC6")};color:{RISK_TEXT.get(cat, "#222")}">{esc(cat)}</span>')


def mode_pill(mode: str, detail: str = "") -> str:
    color = "#2E9E5B" if mode.lower().startswith("live") else "#F2994A"
    return f'<span class="es-pill"><span class="es-dot" style="background:{color}"></span>{esc(mode)}{(" · " + esc(detail)) if detail else ""}</span>'


def timestamp_pill(label: str, value: str) -> str:
    return f'<span class="es-pill">🕒 {esc(label)}: {esc(value)}</span>'


def header_html(subtitle: str, mode: str, mode_detail: str, updated: str) -> str:
    return _one_line(f"""<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.8rem;">
<div class="es-brand">{logo_svg(42)}<div><div class="t">EcoShieldAI</div><div class="s">{esc(subtitle)}</div></div></div>
<div style="display:flex;gap:.5rem;flex-wrap:wrap;">{mode_pill(mode, mode_detail)}{timestamp_pill('Latest data', updated)}</div></div>""")


def banner_html(text: str) -> str:
    return f'<div class="es-banner" role="status">{text}</div>'


def hero_html(district: str, state: str, category: str, score: float | None, horizon: int, as_of: str,
              rain3: float | None, rain7: float | None, caution: str = "") -> str:
    fmt = lambda v: "n/a" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.1f} mm"  # noqa: E731
    sc = "no reliable prediction" if score is None or (isinstance(score, float) and math.isnan(score)) \
        else f"relative risk score {score:.3f} (uncalibrated)"
    col = RISK_COLORS.get(category, "#B8BEC6")
    return _one_line(f"""<div class="es-hero"><span class="es-chip">📍 {esc(district)}, {esc(state)}</span>
<div style="margin-top:1.4rem;font-size:1.5rem;font-weight:500;color:#14213D;">Flood risk</div>
<div class="es-sub" style="color:#4F6075;">Next {horizon} day{'s' if horizon > 1 else ''} · as of {esc(as_of)}</div>
<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:1rem;flex-wrap:wrap;">
<div><div class="es-big" style="color:#14213D;">{esc(category)}</div><div class="es-sub" style="color:#4F6075;">{esc(sc)}</div></div>
<div>{weather_icon_svg(category, 170)}</div></div>
<div class="es-tiles"><div class="es-tile es-lime">Rain, last 3 days<b>{fmt(rain3)}</b></div>
<div class="es-tile es-white">Rain, last 7 days<b>{fmt(rain7)}</b></div>
<div class="es-tile" style="background:{col};color:{RISK_TEXT.get(category, '#222')}">Category<b>{esc(category)}</b></div></div>
{('<div class="es-sub" style="margin-top:1rem;color:#7A4A00;">⚠ ' + esc(caution) + '</div>') if caution else ''}</div>""")


def kpi_html(label: str, value: str, hint: str = "") -> str:
    return _one_line(f"""<div class="es-kpi"><div class="l">{esc(label)}</div><div class="v">{esc(value)}</div>
<div class="es-small">{esc(hint)}</div></div>""")


def district_row_html(rank: int, name: str, state: str, category: str, score, rain3) -> str:
    sc = "n/a" if score is None or (isinstance(score, float) and math.isnan(score)) else f"{score:.3f}"
    r3 = "n/a" if rain3 is None or (isinstance(rain3, float) and math.isnan(rain3)) else f"{rain3:.0f} mm / 3 d"
    return _one_line(f"""<div class="es-row"><div><div class="n">{rank}. {esc(name)}</div><div class="m">{esc(state)} · {r3}</div></div>
<div style="text-align:right">{risk_badge(category)}<div class="m">score {sc}</div></div></div>""")


def navy_model_card(title: str, rows: list[tuple[str, str]], foot: str = "") -> str:
    body = "".join(f'<div style="display:flex;justify-content:space-between;margin:.25rem 0;font-size:.88rem;"><span style="opacity:.75">'
                   f'{esc(k)}</span><b>{esc(v)}</b></div>' for k, v in rows)
    return _one_line(f"""<div class="es-navy"><div style="font-size:1.2rem;font-weight:600;margin-bottom:.5rem;">{esc(title)}</div>{body}
<div style="opacity:.65;font-size:.74rem;margin-top:.6rem;">{esc(foot)}</div>
<div style="position:absolute;right:-8px;bottom:-14px;opacity:.9;">{weather_icon_svg('Moderate', 96)}</div></div>""")


def forecast_days_html(items: list[tuple[str, float | None]]) -> str:
    cells = []
    for label, mm in items:
        val = "n/a" if mm is None or (isinstance(mm, float) and math.isnan(mm)) else f"{mm:.1f}"
        icon = weather_icon_svg("Low" if (mm or 0) < 2.5 else "Moderate" if (mm or 0) < 15 else "High", 56)
        cells.append(f'<div class="es-day">{icon}<div class="mm">{val}<span class="es-small"> mm</span></div><div class="d">{esc(label)}</div></div>')
    return '<div class="es-card" style="display:flex;padding:.9rem .4rem;">' + "".join(cells) + "</div>"


def tomorrow_card_html(district: str, mm: float | None, model: str, note: str) -> str:
    val = "n/a" if mm is None or (isinstance(mm, float) and math.isnan(mm)) else f"{mm:.1f} mm"
    return _one_line(f"""<div class="es-lime-card"><div style="font-size:.85rem;opacity:.8;">Next-day rainfall forecast</div>
<div style="font-size:1.5rem;font-weight:700;margin-top:.1rem;">{esc(district)}</div>
<div style="font-size:2.4rem;font-weight:700;margin-top:1.2rem;">{val}</div><div style="font-size:.8rem;opacity:.8;">{esc(model)}</div>
<div style="font-size:.74rem;opacity:.8;margin-top:.5rem;max-width:62%;">{esc(note)}</div>
<div style="position:absolute;right:6px;bottom:2px;">{umbrella_svg(130)}</div></div>""")


def confusion_matrix_html(cm: dict) -> str:
    tn, fp, fn, tp = (cm.get(k, 0) for k in ("tn", "fp", "fn", "tp"))
    c = lambda v, bg: f'<td style="background:{bg}">{v:,}</td>'  # noqa: E731
    return _one_line(f"""<table class="es-cm" style="border-spacing:6px;border-collapse:separate;width:100%;color:#14213D;">
<tr><td></td><td class="es-small">Predicted: no flood</td><td class="es-small">Predicted: flood</td></tr>
<tr><td class="es-small">Actual: no flood</td>{c(tn, '#DDEFE3')}{c(fp, '#FBE1C6')}</tr>
<tr><td class="es-small">Actual: flood</td>{c(fn, '#F6D3D3')}{c(tp, '#CFE9F2')}</tr></table>""")
