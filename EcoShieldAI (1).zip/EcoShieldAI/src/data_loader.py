"""Robust CSV loading with schema discovery. Original files are only ever READ."""
from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from .utils import resolve_path, to_snake

log = logging.getLogger("ecoshield")


class SchemaError(ValueError):
    pass


RAIN_REQUIRED = ["date", "state_code", "state_name", "district_code", "district_name", "actual"]
RAIN_OPTIONAL = ["rfs", "normal", "deviation", "id"]
FLOOD_REQUIRED = ["start_date", "end_date", "state"]
FLOOD_OPTIONAL = ["uei", "duration_days", "main_cause", "districts", "district_lgd_codes", "state_codes"]


def read_csv_robust(path: Path, **kwargs) -> tuple[pd.DataFrame, dict]:
    """Read a CSV; detect encoding problems and malformed rows instead of silently dropping them."""
    info = {"path": str(path), "encoding": "utf-8", "malformed_rows": 0}
    kw = dict(kwargs)
    for enc in ("utf-8", "latin-1"):
        try:
            df = pd.read_csv(path, encoding=enc, **kw)
            info["encoding"] = enc
            if enc != "utf-8":
                log.warning("%s is not valid UTF-8; decoded as %s", path.name, enc)
            return df, info
        except UnicodeDecodeError:
            continue
        except pd.errors.ParserError as exc:
            log.warning("Malformed rows in %s (%s); re-reading with a bad-line collector", path.name, exc)
            bad: list = []
            df = pd.read_csv(path, encoding=enc, engine="python", on_bad_lines=lambda row: bad.append(row) or None, **kw)
            info.update(encoding=enc, malformed_rows=len(bad))
            return df, info
    raise SchemaError(f"Could not decode {path}")


def discover_schema(path: Path, nrows: int = 200) -> dict:
    """Programmatically discover columns/dtypes (no assumptions)."""
    sample, _ = read_csv_robust(path, nrows=nrows)
    return {"columns": list(sample.columns), "snake": [to_snake(c) for c in sample.columns],
            "dtypes": {c: str(t) for c, t in sample.dtypes.items()}}


def parse_dates_best(series: pd.Series, candidates: tuple[str, ...]) -> tuple[pd.Series, str, int]:
    """Try several formats, keep the one that parses most values; remaining failures are returned as NaT."""
    best, best_fmt, best_ok = None, "", -1
    for fmt in candidates:
        parsed = pd.to_datetime(series, format=fmt, errors="coerce")
        ok = int(parsed.notna().sum())
        if ok > best_ok:
            best, best_fmt, best_ok = parsed, fmt, ok
    n_missing_raw = int(series.isna().sum())
    invalid = int(len(series) - best_ok - n_missing_raw)
    return best, best_fmt, invalid


def _check_columns(df: pd.DataFrame, required: list[str], what: str) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise SchemaError(f"{what}: required columns missing after standardisation: {missing}. Found: {list(df.columns)}")


def load_rainfall_raw(cfg: dict) -> tuple[pd.DataFrame, dict]:
    path = resolve_path(cfg, "raw_dir", cfg["paths"]["rainfall_csv"])
    if not path.exists():
        raise FileNotFoundError(f"Rainfall CSV not found at {path}. Place the original file in data/raw/.")
    schema = discover_schema(path)
    keep = [c for c, s in zip(schema["columns"], schema["snake"]) if s in RAIN_REQUIRED + RAIN_OPTIONAL]
    df, info = read_csv_robust(path, usecols=keep, dtype={"state_name": "string", "district_name": "string"})
    df.columns = [to_snake(c) for c in df.columns]
    _check_columns(df, RAIN_REQUIRED, "rainfall")
    info.update(schema=schema, rows_loaded=len(df))
    log.info("Loaded rainfall: %s rows", f"{len(df):,}")
    return df, info


def load_floods_raw(cfg: dict) -> tuple[pd.DataFrame, dict]:
    path = resolve_path(cfg, "raw_dir", cfg["paths"]["flood_csv"])
    if not path.exists():
        raise FileNotFoundError(f"Flood inventory CSV not found at {path}. Place the original file in data/raw/.")
    schema = discover_schema(path)
    df, info = read_csv_robust(path, dtype=str)
    df.columns = [to_snake(c) for c in df.columns]
    _check_columns(df, FLOOD_REQUIRED, "flood inventory")
    info.update(schema=schema, rows_loaded=len(df))
    log.info("Loaded flood inventory: %s rows", f"{len(df):,}")
    return df, info
