"""Feature selection using TRAINING data only (chronological inner split for permutation importance)."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.metrics import roc_auc_score

from .feature_engineering import leakage_prone

log = logging.getLogger("ecoshield")


def _balanced_sample(df: pd.DataFrame, y: np.ndarray, n_rows: int, rng) -> np.ndarray:
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)
    n_pos = min(len(pos), n_rows // 4)
    n_neg = min(len(neg), n_rows - n_pos)
    idx = np.concatenate([rng.choice(pos, n_pos, replace=False), rng.choice(neg, n_neg, replace=False)])
    return idx


def select_features(train: pd.DataFrame, y: np.ndarray, candidates: list[str], cfg: dict, seed: int = 42) -> dict:
    rng = np.random.default_rng(seed)
    dropped: dict[str, str] = {}
    cols = [c for c in candidates if c not in leakage_prone(candidates)]
    for c in set(candidates) - set(cols):
        dropped[c] = "leakage-prone name"
    idx = _balanced_sample(train, y, cfg["selection"]["permutation_rows"], rng)
    idx = idx[np.argsort(train["date"].values[idx], kind="stable")]       # chronological order inside TRAIN
    S = train.iloc[idx][cols].astype("float32")
    ys = y[idx]

    const = [c for c in cols if S[c].nunique(dropna=True) <= 1]
    for c in const:
        dropped[c] = "constant"
    cols = [c for c in cols if c not in const]
    Xi = pd.DataFrame(SimpleImputer(strategy="median").fit_transform(S[cols]), columns=cols)

    mi = pd.Series(mutual_info_classif(Xi.values, ys, random_state=seed), index=cols)
    kept: list[str] = []
    corr = Xi.corr().abs()
    for c in mi.sort_values(ascending=False).index:                       # keep the most informative of a correlated group
        if all(corr.loc[c, k] < cfg["selection"]["corr_threshold"] for k in kept):
            kept.append(c)
        else:
            dropped[c] = f"redundant (|corr| >= {cfg['selection']['corr_threshold']})"

    cut = int(len(Xi) * 0.8)                                              # inner chronological split of TRAIN
    rf = RandomForestClassifier(n_estimators=80, max_depth=10, min_samples_leaf=20, class_weight="balanced",
                                n_jobs=1, random_state=seed).fit(Xi.iloc[:cut][kept], ys[:cut])
    hold_y = ys[cut:]
    perm = pd.Series(0.0, index=kept)
    if hold_y.sum() > 0 and hold_y.sum() < len(hold_y):
        res = permutation_importance(rf, Xi.iloc[cut:][kept], hold_y, scoring="roc_auc", n_repeats=3,
                                     random_state=seed, n_jobs=1)
        perm = pd.Series(res.importances_mean, index=kept)
    rf_imp = pd.Series(rf.feature_importances_, index=kept)
    median_mi = mi[kept].median()
    final = []
    for c in kept:
        if perm[c] <= 0 and mi[c] < median_mi:
            dropped[c] = "no signal (permutation importance <= 0 and MI below median)"
        else:
            final.append(c)
    table = pd.DataFrame({"mutual_info": mi, "permutation_importance": perm, "rf_importance": rf_imp}).reindex(candidates)
    table["selected"] = table.index.isin(final)
    table["drop_reason"] = pd.Series(dropped)
    log.info("Feature selection kept %d of %d candidates", len(final), len(candidates))
    return {"selected": final, "dropped": dropped, "table": table}
