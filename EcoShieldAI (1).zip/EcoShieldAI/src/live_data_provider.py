"""Configurable live-data layer (disabled by default).

IMPORTANT - what this layer can and cannot claim
  * It fetches gridded model/analysis rainfall (default provider: Open-Meteo) for district centroids. That is NOT the
    gauge-based IMD district rainfall the classifier was trained on, so the classifier is deliberately NOT applied to it.
    Live mode shows observed-to-date and forecast rainfall only; flood-risk scores stay historical.
  * Terms of use, coverage, units and licensing of the provider must be verified by you before enabling
    (config/settings.yaml -> live.enabled). Nothing here fabricates data: on any failure the app falls back to
    Historical/Demo mode and says so.
  * Credentials come from environment variables / Streamlit secrets only.
"""
from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

log = logging.getLogger("ecoshield")


@dataclass
class LiveResult:
    status: str                      # ok | cached | stale | disabled | error
    message: str = ""
    data: pd.DataFrame | None = None  # district_code, date, precip_mm, kind(observed|forecast)
    source: str = ""
    retrieved_at: datetime | None = None
    latest_observation_date: str | None = None
    meta: dict = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.status in ("ok", "cached") and self.data is not None and not self.data.empty

    @property
    def age_hours(self) -> float | None:
        return None if self.retrieved_at is None else (datetime.now(timezone.utc) - self.retrieved_at).total_seconds() / 3600


class ProviderError(Exception):
    pass


class OpenMeteoProvider:
    name = "open-meteo"

    def __init__(self, live_cfg: dict, centroids: dict[int, tuple[float, float]], cache_dir: Path,
                 api_key: str | None = None, session=None, sleep=time.sleep):
        self.cfg = live_cfg
        self.centroids = centroids
        self.cache_path = Path(cache_dir) / "open_meteo_latest.json"
        self.api_key = api_key
        self.sleep = sleep
        if session is None:
            import requests
            session = requests.Session()
        self.session = session

    # ----------------------------------------------------------------------------------- http
    def _get(self, params: dict) -> object:
        last: Exception | None = None
        for attempt in range(1, int(self.cfg["retries"]) + 1):
            try:
                r = self.session.get(self.cfg["base_url"], params=params, timeout=self.cfg["timeout_s"])
                if r.status_code == 429:
                    wait = min(float(r.headers.get("Retry-After", 2 ** attempt)), 30.0)
                    last = ProviderError("The data provider is rate-limiting requests; try again in a few minutes.")
                    self.sleep(wait)
                    continue
                if r.status_code >= 500:
                    last = ProviderError(f"Data provider error (HTTP {r.status_code}).")
                    self.sleep(2 ** attempt)
                    continue
                if r.status_code != 200:
                    raise ProviderError(f"Data provider rejected the request (HTTP {r.status_code}).")
                return r.json()
            except ProviderError:
                raise
            except Exception as exc:  # noqa: BLE001 - timeouts, connection and JSON errors
                last = ProviderError("Could not reach the data provider (network problem or timeout).")
                log.warning("live fetch attempt %d failed: %s", attempt, exc)
                self.sleep(2 ** attempt)
        raise last or ProviderError("Unknown provider failure")

    # --------------------------------------------------------------------------------- parsing
    @staticmethod
    def parse_batch(payload, codes: list[int]) -> pd.DataFrame:
        """Validate and convert one batch response to rows. Raises ProviderError on anything unexpected."""
        items = payload if isinstance(payload, list) else [payload]
        if len(items) != len(codes):
            raise ProviderError("Provider returned an unexpected number of locations.")
        rows = []
        for code, it in zip(codes, items):
            daily = (it or {}).get("daily") if isinstance(it, dict) else None
            units = ((it or {}).get("daily_units") or {}).get("precipitation_sum")
            if not daily or "time" not in daily or "precipitation_sum" not in daily:
                raise ProviderError("Provider response is missing daily precipitation.")
            if units != "mm":
                raise ProviderError(f"Unexpected rainfall unit '{units}' (expected mm).")
            if len(daily["time"]) != len(daily["precipitation_sum"]):
                raise ProviderError("Provider response has mismatched array lengths.")
            for d, v in zip(daily["time"], daily["precipitation_sum"]):
                rows.append((int(code), d, None if v is None else float(v)))
        df = pd.DataFrame(rows, columns=["district_code", "date", "precip_mm"])
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if df["date"].isna().any():
            raise ProviderError("Provider returned invalid dates.")
        return df

    # ----------------------------------------------------------------------------------- cache
    def _read_cache(self) -> LiveResult | None:
        try:
            raw = json.loads(self.cache_path.read_text(encoding="utf-8"))
            ts = datetime.fromisoformat(raw["retrieved_at"])
            df = pd.DataFrame(raw["rows"])
            df["date"] = pd.to_datetime(df["date"])
            return self._finalise(df, ts, "cached")
        except Exception:  # noqa: BLE001
            return None

    def _write_cache(self, df: pd.DataFrame, ts: datetime) -> None:
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            rows = df.assign(date=df["date"].dt.strftime("%Y-%m-%d")).to_dict("records")
            self.cache_path.write_text(json.dumps({"retrieved_at": ts.isoformat(), "rows": rows}), encoding="utf-8")
        except OSError as exc:
            log.warning("could not write live cache: %s", exc)

    def _finalise(self, df: pd.DataFrame, ts: datetime, status: str) -> LiveResult:
        today = pd.Timestamp(ts.astimezone(timezone(timedelta(hours=5, minutes=30))).date())   # IST calendar day
        df = df.copy()
        df["kind"] = (df["date"] > today).map({True: "forecast", False: "observed"})
        obs = df[(df["kind"] == "observed") & df["precip_mm"].notna()]
        latest = None if obs.empty else str(obs["date"].max().date())
        age_h = (datetime.now(timezone.utc) - ts).total_seconds() / 3600
        if age_h > float(self.cfg["max_staleness_hours"]):
            status = "stale"
        return LiveResult(status, "" if status != "stale" else f"Live data is {age_h:.1f} h old (limit {self.cfg['max_staleness_hours']} h).",
                          df, self.name, ts, latest, {"age_hours": age_h, "units": "mm/day", "timezone": "Asia/Kolkata",
                                                      "nature": "gridded model/analysis rainfall (not IMD gauge data)"})

    # ---------------------------------------------------------------------------------- public
    def fetch(self, force: bool = False) -> LiveResult:
        if not self.centroids:
            return LiveResult("error", "No district coordinates available (district boundary file required).")
        if not force:
            cached = self._read_cache()
            if cached is not None and (cached.age_hours or 1e9) * 60 < float(self.cfg["cache_ttl_minutes"]):
                return cached
        codes = sorted(self.centroids)
        frames, bs = [], int(self.cfg["batch_size"])
        try:
            for i in range(0, len(codes), bs):
                chunk = codes[i:i + bs]
                params = {"latitude": ",".join(f"{self.centroids[c][0]:.4f}" for c in chunk),
                          "longitude": ",".join(f"{self.centroids[c][1]:.4f}" for c in chunk),
                          "daily": "precipitation_sum", "timezone": "Asia/Kolkata",
                          "past_days": int(self.cfg["past_days"]), "forecast_days": int(self.cfg["forecast_days"])}
                if self.api_key:
                    params["apikey"] = self.api_key
                frames.append(self.parse_batch(self._get(params), chunk))
        except ProviderError as exc:
            fallback = self._read_cache()
            if fallback is not None:
                fallback.message = f"{exc} Showing last cached data."
                fallback.status = "stale"
                return fallback
            return LiveResult("error", str(exc))
        ts = datetime.now(timezone.utc)
        df = pd.concat(frames, ignore_index=True)
        self._write_cache(df, ts)
        return self._finalise(df, ts, "ok")


def get_api_key(cfg: dict, secrets=None) -> str | None:
    name = cfg["live"].get("api_key_env", "OPEN_METEO_API_KEY")
    if os.environ.get(name):
        return os.environ[name]
    try:
        return secrets[name] if secrets is not None and name in secrets else None
    except Exception:  # noqa: BLE001
        return None


def disabled_result() -> LiveResult:
    return LiveResult("disabled", "Live data is disabled (config live.enabled = false). Showing Historical/Demo data.")
