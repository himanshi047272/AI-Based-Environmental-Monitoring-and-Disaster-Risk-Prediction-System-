"""District rainfall forecasting with ARIMA / SARIMA (statsmodels SARIMAX) for the next 1-3 days.

ARIMA/SARIMA forecast RAINFALL ONLY. They do not predict floods; flood risk comes from the classifier and is shown separately.

Protocol per district (all chronological):
  fit window -> [validation origins: choose order / seasonality by RMSE] -> [test origins: report RMSE/MSE/R2 vs baselines]
  -> final refit on the most recent window -> operational forecast for the next 1, 2, 3 days.
Missing rainfall stays NaN (the state-space model handles missing observations); it is never treated as zero.
Districts without enough reliable history are reported as `unavailable` - no values are fabricated.
"""
from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable

import numpy as np
import pandas as pd

from .evaluate_models import regression_metrics
from .utils import resolve_path, save_json

log = logging.getLogger("ecoshield")


# ------------------------------------------------------------------------------------- series utils
def acf_at_lag(x: np.ndarray, lag: int) -> float:
    """Sample autocorrelation at `lag`, ignoring NaN pairs (no zero filling)."""
    x = np.asarray(x, float)
    if lag <= 0 or len(x) <= lag + 2:
        return float("nan")
    a, b = x[:-lag], x[lag:]
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < 10:
        return float("nan")
    a, b = a[ok], b[ok]
    if a.std() == 0 or b.std() == 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def choose_seasonal_period(x: np.ndarray, candidates, significance: float = 2.0) -> int | None:
    """Return the candidate period with the strongest significant ACF, else None (=> plain ARIMA)."""
    n = int(np.isfinite(x).sum())
    if n < 60:
        return None
    bound = significance / np.sqrt(n)
    best, best_val = None, bound
    for s in candidates:
        v = acf_at_lag(x, int(s))
        if np.isfinite(v) and v > best_val:
            best, best_val = int(s), v
    return best


def check_sufficient(series: np.ndarray, min_days: int, min_fraction: float = 0.8) -> tuple[bool, str]:
    n_obs = int(np.isfinite(series).sum())
    if n_obs < min_days:
        return False, f"insufficient history ({n_obs} observed days < {min_days})"
    if n_obs / max(1, len(series)) < min_fraction:
        return False, f"too many missing days ({n_obs}/{len(series)} observed)"
    return True, ""


def baseline_forecasts(history: np.ndarray, steps: int) -> dict[str, np.ndarray]:
    """Simple benchmarks computed from observations up to the origin only."""
    h = np.asarray(history, float)
    obs = h[np.isfinite(h)]
    last = obs[-1] if len(obs) else np.nan
    last7 = h[-7:]
    m7 = float(np.nanmean(last7)) if np.isfinite(last7).any() else np.nan
    return {"persistence": np.full(steps, last), "mean_last7": np.full(steps, m7)}


# ------------------------------------------------------------------------------------- model wrapper
@dataclass
class Fitted:
    result: object
    order: tuple
    seasonal: tuple
    sqrt: bool
    meta: dict = field(default_factory=dict)

    def forecast(self, steps: int) -> np.ndarray:
        f = np.asarray(self.result.forecast(steps), float)
        f = np.clip(f, 0, None)
        return f ** 2 if self.sqrt else f

    def apply(self, endog: np.ndarray) -> "Fitted":
        y = np.sqrt(endog) if self.sqrt else endog
        return Fitted(self.result.apply(y, refit=False), self.order, self.seasonal, self.sqrt, self.meta)


def fit_sarimax(endog: np.ndarray, order: tuple, seasonal: tuple, sqrt: bool = True) -> Fitted:
    """Fit ARIMA (seasonal == (0,0,0,0)) or SARIMA. Raises on failure; callers handle it."""
    try:
        from statsmodels.tsa.statespace.sarimax import SARIMAX
    except ImportError as exc:  # pragma: no cover
        raise ImportError("statsmodels is required for ARIMA/SARIMA (pip install statsmodels)") from exc
    y = np.sqrt(endog) if sqrt else np.asarray(endog, float)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        mod = SARIMAX(y, order=order, seasonal_order=seasonal, trend="c" if order[1] == 0 and seasonal[1] == 0 else "n",
                      enforce_stationarity=False, enforce_invertibility=False)
        res = mod.fit(disp=False, maxiter=60)
    converged = bool(getattr(res, "mle_retvals", {}).get("converged", True))
    if not converged or not np.isfinite(res.llf):
        raise RuntimeError("SARIMAX did not converge")
    return Fitted(res, order, seasonal, sqrt, {"aic": float(res.aic), "converged": converged})


Fitter = Callable[[np.ndarray, tuple, tuple, bool], Fitted]


def model_label(order, seasonal) -> str:
    return f"SARIMA{tuple(order)}x{tuple(seasonal)}" if seasonal[3] else f"ARIMA{tuple(order)}"


# ------------------------------------------------------------------------------------- evaluation
def _origins(dates: pd.DatetimeIndex, start, end, stride: int, steps: int, n: int) -> list[int]:
    s = int(dates.get_indexer([pd.Timestamp(start)], method="bfill")[0])
    e = int(dates.get_indexer([pd.Timestamp(end)], method="ffill")[0])
    return [i for i in range(s, e + 1, stride) if i + steps < n]


def _eval_origins(model: Fitted | None, series: np.ndarray, origins: list[int], steps: int, window: int):
    """Forecast `steps` days from each origin (data up to and including origin). Returns dict[name] -> (pred[o,h], truth[o,h])."""
    out = {}
    truth = np.array([[series[o + h] for h in range(1, steps + 1)] for o in origins], float)
    out["truth"] = truth
    preds, p_pers, p_m7 = [], [], []
    for o in origins:
        hist = series[max(0, o + 1 - window): o + 1]
        b = baseline_forecasts(hist, steps)
        p_pers.append(b["persistence"]); p_m7.append(b["mean_last7"])
        if model is not None:
            preds.append(model.apply(hist).forecast(steps))
    out["persistence"], out["mean_last7"] = np.array(p_pers), np.array(p_m7)
    if model is not None:
        out["model"] = np.array(preds)
    return out


def forecast_district(series: np.ndarray, dates: pd.DatetimeIndex, fc: dict, as_of_idx: int,
                      fitter: Fitter = fit_sarimax) -> dict:
    """Full per-district workflow. `series` is daily rainfall with NaN gaps; `as_of_idx` is the forecast origin."""
    steps, window = fc["horizon_days"], fc["fit_window_days"]
    sqrt = fc.get("sqrt_transform", True)
    stride = fc.get("eval_stride_days", 3)
    v0, v1 = fc["validation_origin_start"], fc["validation_origin_end"]
    t0, t1 = fc["test_origin_start"], fc["test_origin_end"]
    result = {"status": "unavailable", "reason": ""}
    ok, why = check_sufficient(series[: as_of_idx + 1], fc["min_history_days"])
    if not ok:
        result["reason"] = why
        return result
    n = len(series)
    v_origins = _origins(dates, v0, v1, stride, steps, n)
    t_origins = _origins(dates, t0, t1, stride, steps, n)
    if not v_origins or not t_origins:
        result["reason"] = "validation/test origins fall outside the available data"
        return result
    train_end = v_origins[0]                                  # fit strictly before the first validation origin
    train = series[max(0, train_end + 1 - window): train_end + 1]
    ok, why = check_sufficient(train, min(fc["min_history_days"], window) // 2, 0.6)
    if not ok:
        result["reason"] = why
        return result
    period = choose_seasonal_period(np.sqrt(train) if sqrt else train, fc["seasonal_period_candidates"], fc["acf_significance"])
    cands = [(tuple(o), (0, 0, 0, 0)) for o in fc["orders"]]
    if period:
        cands += [(tuple(o), (1, 0, 0, period)) for o in fc["orders"][:2]]

    best = None
    for order, seas in cands:                                 # tune on VALIDATION origins only
        try:
            m = fitter(train, order, seas, sqrt)
            ev = _eval_origins(m, series, v_origins, steps, window)
            rmse = float(np.sqrt(np.nanmean((ev["model"] - ev["truth"]) ** 2)))
        except Exception as exc:  # noqa: BLE001 - convergence / numerical errors must not stop the run
            log.debug("candidate %s failed: %s", model_label(order, seas), exc)
            continue
        if np.isfinite(rmse) and (best is None or rmse < best[0]):
            best = (rmse, order, seas)
    if best is None:
        result["reason"] = "no ARIMA/SARIMA candidate converged"
        return result
    val_rmse, order, seas = best

    try:                                                      # refit up to test boundary, evaluate on TEST origins
        test_train_end = t_origins[0]
        m_test = fitter(series[max(0, test_train_end + 1 - window): test_train_end + 1], order, seas, sqrt)
        ev = _eval_origins(m_test, series, t_origins, steps, window)
        final_hist = series[max(0, as_of_idx + 1 - window): as_of_idx + 1]
        m_final = fitter(final_hist, order, seas, sqrt)
        fc_vals = m_final.forecast(steps)
    except Exception as exc:  # noqa: BLE001
        result["reason"] = f"final fit failed: {exc}"
        return result
    result.update(status="ok", reason="", model=model_label(order, seas), order=order, seasonal=seas,
                  seasonal_period=period, validation_rmse=val_rmse, forecast=fc_vals.tolist(),
                  diagnostics=m_final.meta, test=ev)
    return result


def pooled_metrics(per_district: dict[int, dict], steps: int) -> dict:
    """Pool test forecasts across districts/origins -> RMSE, MSE, R2 for each horizon and method."""
    out = {}
    for name in ("model", "persistence", "mean_last7"):
        out[name] = {}
        for h in range(steps):
            yt, yp = [], []
            for r in per_district.values():
                if r["status"] == "ok":
                    yt.append(r["test"]["truth"][:, h]); yp.append(r["test"][name][:, h])
            out[name][f"h{h + 1}"] = regression_metrics(np.concatenate(yt), np.concatenate(yp)) if yt else {}
    return out


# ------------------------------------------------------------------------------------- orchestration
def run_forecasting(cfg: dict, fitter: Fitter = fit_sarimax) -> dict:
    from joblib import Parallel, delayed
    from .flood_risk_prediction import latest_feasible_index, load_cube

    fc = cfg["forecast"]
    cube = load_cube(cfg)
    dates, codes, actual = cube["dates"], cube["codes"], cube["actual"]
    as_of = latest_feasible_index(actual, cfg["snapshots"]["min_feature_complete_fraction"])
    sel = list(range(len(codes)))
    if fc.get("max_districts"):
        sel = sel[: int(fc["max_districts"])]
    log.info("Forecasting %d districts from as-of %s", len(sel), dates[as_of].date())

    def one(j):
        try:
            return j, forecast_district(actual[:, j], dates, fc, as_of, fitter)
        except Exception as exc:  # noqa: BLE001
            return j, {"status": "unavailable", "reason": f"error: {exc}"}

    res = dict(Parallel(n_jobs=fc.get("n_jobs", 1))(delayed(one)(j) for j in sel))
    now = datetime.now().isoformat(timespec="seconds")
    rows, cfgrows = [], []
    for j, r in res.items():
        code = int(codes[j])
        for h in range(1, fc["horizon_days"] + 1):
            rows.append({"district_code": code, "as_of_date": dates[as_of].date().isoformat(),
                         "forecast_date": (dates[as_of] + pd.Timedelta(days=h)).date().isoformat(), "horizon_days": h,
                         "forecast_rain_mm": (r["forecast"][h - 1] if r["status"] == "ok" else np.nan),
                         "status": r["status"], "reason": r["reason"], "model": r.get("model", ""),
                         "generated_at": now, "data_mode": "historical"})
        cfgrows.append({"district_code": code, "status": r["status"], "reason": r["reason"], "model": r.get("model", ""),
                        "seasonal_period": r.get("seasonal_period"), "validation_rmse": r.get("validation_rmse"),
                        "aic": (r.get("diagnostics") or {}).get("aic")})
    out_dir = resolve_path(cfg, "forecasts_dir", create=True)
    pd.DataFrame(rows).to_csv(out_dir / "latest_forecast.csv", index=False)
    pd.DataFrame(cfgrows).to_csv(out_dir / "forecast_model_config.csv", index=False)
    metrics = pooled_metrics(res, fc["horizon_days"])
    n_ok = sum(r["status"] == "ok" for r in res.values())
    meta = {"generated_at": now, "as_of_date": str(dates[as_of].date()), "districts_attempted": len(res), "districts_ok": n_ok,
            "evaluation": {"validation_origins": [fc["validation_origin_start"], fc["validation_origin_end"]],
                           "test_origins": [fc["test_origin_start"], fc["test_origin_end"]]},
            "metrics_test": metrics,
            "note": ("RMSE/MSE/R2 evaluate RAINFALL forecasts only. R2 is negative when a forecast is worse than predicting the "
                     "observed mean. These are historical hold-out results, not live forecasts.")}
    save_json(meta, out_dir / "forecast_metrics.json")
    log.info("Forecasts available for %d / %d districts", n_ok, len(res))
    return meta
