"""Metrics. Classification: ROC-AUC, accuracy, precision, recall, confusion matrix.
Regression (rainfall forecasts ONLY): RMSE, MSE, R2. Regression metrics are never computed for binary flood labels."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, mean_squared_error, precision_recall_curve,
                             precision_score, r2_score, recall_score, roc_auc_score)


def classification_metrics(y_true, score, threshold: float) -> dict:
    y = np.asarray(y_true).astype(int)
    pred = (np.asarray(score) >= threshold).astype(int)
    auc = float(roc_auc_score(y, score)) if len(np.unique(y)) == 2 else float("nan")
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "roc_auc": auc,
        "accuracy": float(accuracy_score(y, pred)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "threshold": float(threshold), "n": int(len(y)), "n_positive": int(y.sum()),
    }


def regression_metrics(y_true, y_pred) -> dict:
    """RMSE / MSE / R2 for continuous forecasts. R2 can be NEGATIVE when the model is worse than predicting the mean."""
    yt, yp = np.asarray(y_true, float), np.asarray(y_pred, float)
    ok = np.isfinite(yt) & np.isfinite(yp)
    yt, yp = yt[ok], yp[ok]
    if len(yt) < 2:
        return {"rmse": float("nan"), "mse": float("nan"), "r2": float("nan"), "n": int(len(yt))}
    mse = float(mean_squared_error(yt, yp))
    r2 = float(r2_score(yt, yp)) if np.var(yt) > 0 else float("nan")
    return {"rmse": float(np.sqrt(mse)), "mse": mse, "r2": r2, "n": int(len(yt))}


def select_threshold(y_true, score, method: str = "f1", min_recall: float = 0.7) -> float:
    """Choose the decision threshold on VALIDATION data only."""
    y = np.asarray(y_true).astype(int)
    if y.sum() == 0:
        return 0.5
    p, r, t = precision_recall_curve(y, score)
    p, r = p[:-1], r[:-1]
    if method == "min_recall":
        ok = r >= min_recall
        if ok.any():
            return float(t[ok][np.argmax(p[ok])])
    f1 = np.where(p + r > 0, 2 * p * r / np.maximum(p + r, 1e-12), 0)
    return float(t[int(np.argmax(f1))])


def best_f1(y_true, score) -> float:
    y = np.asarray(y_true).astype(int)
    if y.sum() == 0:
        return 0.0
    p, r, _ = precision_recall_curve(y, score)
    f1 = np.where(p + r > 0, 2 * p * r / np.maximum(p + r, 1e-12), 0)
    return float(f1.max())
