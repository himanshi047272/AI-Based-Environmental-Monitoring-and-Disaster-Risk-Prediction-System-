"""Cleaning + data-quality reporting. Nothing is silently dropped: rejected rows are returned and reported."""
from __future__ import annotations

import logging
import re

import numpy as np
import pandas as pd

from .data_loader import parse_dates_best
from .utils import normalize_name, save_json

log = logging.getLogger("ecoshield")

RAIN_DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d")
FLOOD_DATE_FORMATS = ("%d-%m-%Y %H:%M", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y")


# --------------------------------------------------------------------------------------- rainfall
def clean_rainfall(df: pd.DataFrame, cfg: dict) -> tuple[pd.DataFrame, dict]:
    """Return (clean, report). Clean has ONE row per (district_code, date) for non-ambiguous codes."""
    dcfg = cfg["data"]
    df = df.reset_index(drop=True)
    report: dict = {"rows_loaded": int(len(df))}

    df["date"], fmt, invalid = parse_dates_best(df["date"], RAIN_DATE_FORMATS)
    report.update(date_format=fmt, invalid_dates=invalid)
    bad_date = df["date"].isna()
    rejected = df.loc[bad_date].copy()
    df = df.loc[~bad_date].copy()

    for c in ("state_code", "district_code"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    bad_code = df["district_code"].isna() | df["state_code"].isna()
    report["invalid_codes"] = int(bad_code.sum())
    rejected = pd.concat([rejected, df.loc[bad_code]])
    df = df.loc[~bad_code].copy()
    df["state_code"] = df["state_code"].astype("int32")
    df["district_code"] = df["district_code"].astype("int32")

    for c in ("actual", "rfs", "normal", "deviation"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").astype("float32")
    invalid_rain = (df["actual"] < 0) | (df["actual"] > dcfg["max_daily_rainfall_mm"])
    report["invalid_rainfall_values_set_nan"] = int(invalid_rain.sum())
    df.loc[invalid_rain, "actual"] = np.nan   # never replaced with zero

    for c in ("state_name", "district_name"):
        df[c] = df[c].astype("string").str.strip()
    df["state_norm"] = df["state_name"].map(normalize_name)
    df["district_norm"] = df["district_name"].map(normalize_name)

    # ---- duplicates: identical rows collapse; conflicting rows are ambiguity evidence
    keys = ["district_code", "date"]
    dup_all = df.duplicated(keys, keep=False)
    report["duplicate_district_days_rows"] = int(dup_all.sum())
    value_cols = [c for c in ("actual", "rfs", "normal", "deviation") if c in df.columns]
    conflicting = pd.Series(False, index=df.index)
    if dup_all.any():
        sub = df.loc[dup_all]
        nun = sub.groupby(keys)[value_cols].nunique(dropna=False).max(axis=1)
        conflict_keys = nun[nun > 1].index
        if len(conflict_keys):
            idx = sub.set_index(keys).index.isin(conflict_keys)
            conflicting.loc[sub.index[idx]] = True
    n_days = df.groupby("district_code")["date"].nunique()
    conf_days = df.loc[conflicting].groupby("district_code")["date"].nunique().reindex(n_days.index).fillna(0)
    frac = conf_days / n_days
    ambiguous = sorted(frac[frac > dcfg["ambiguous_code_conflict_fraction"]].index.astype(int).tolist())
    report["ambiguous_district_codes"] = ambiguous
    report["ambiguous_code_detail"] = {
        int(c): {"district_names": sorted(df.loc[df.district_code == c, "district_name"].dropna().unique().tolist()),
                 "state_codes": sorted(df.loc[df.district_code == c, "state_code"].unique().tolist()),
                 "conflicting_day_fraction": float(frac[c])} for c in ambiguous}
    # ambiguous codes: excluded entirely (two entities share one code, cannot be separated)
    amb_mask = df["district_code"].isin(ambiguous)
    report["rows_excluded_ambiguous_codes"] = int(amb_mask.sum())
    rejected = pd.concat([rejected, df.loc[amb_mask]])
    df = df.loc[~amb_mask]
    # remaining conflicts: keep the row with an observed `actual`; set actual NaN if still conflicting
    conflicting = conflicting.loc[df.index]
    report["conflicting_rows_in_non_ambiguous_codes"] = int(conflicting.sum())
    if conflicting.any():
        df.loc[conflicting, "actual"] = np.nan
    before = len(df)
    df = df.drop_duplicates(keys, keep="first")
    report["duplicate_rows_removed"] = int(before - len(df))

    df = df.sort_values(keys).reset_index(drop=True)
    report.update(
        rows_clean=int(len(df)),
        rows_rejected=int(len(rejected)),
        date_min=str(df["date"].min().date()), date_max=str(df["date"].max().date()),
        n_districts=int(df["district_code"].nunique()), n_states=int(df["state_code"].nunique()),
        missing_values={c: int(df[c].isna().sum()) for c in value_cols},
    )
    stats = df.groupby("district_code").agg(
        n_days=("date", "nunique"), n_actual=("actual", lambda s: int(s.notna().sum())))
    stats["observed_fraction"] = stats["n_actual"] / stats["n_days"]
    insufficient = stats[(stats["n_actual"] < dcfg["min_history_days"])
                         | (stats["observed_fraction"] < dcfg["min_observed_fraction"])]
    report["insufficient_history_districts"] = insufficient.index.astype(int).tolist()
    report["n_insufficient_history"] = int(len(insufficient))
    report["rejected_sample"] = rejected.head(20).astype(str).to_dict("records")
    return df, report


# ----------------------------------------------------------------------------------------- floods
_TOKEN = re.compile(r"^\d+$")


def parse_code_list(value) -> tuple[list[int], int]:
    """'348, 352, None, 368' -> ([348, 352, 368], 1 invalid token)."""
    if value is None or (isinstance(value, float) and np.isnan(value)) or str(value).strip() == "":
        return [], 0
    ints, bad = [], 0
    for tok in str(value).split(","):
        tok = tok.strip()
        if _TOKEN.match(tok):
            ints.append(int(tok))
        elif tok:
            bad += 1
    return ints, bad


def parse_name_list(value) -> list[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)) or str(value).strip() == "":
        return []
    return [t.strip() for t in str(value).split(",") if t.strip() and t.strip().lower() != "none"]


def clean_floods(df: pd.DataFrame) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    """Return (events, report, rejected). Events keep original code strings for traceability."""
    df = df.copy()
    report: dict = {"rows_loaded": int(len(df))}
    df["start_date"], fmt, inv_s = parse_dates_best(df["start_date"], FLOOD_DATE_FORMATS)
    df["end_date"], _, inv_e = parse_dates_best(df["end_date"], FLOOD_DATE_FORMATS)
    report.update(date_format=fmt, invalid_start_dates=inv_s, invalid_end_dates=inv_e)

    bad = df["start_date"].isna()
    report["missing_or_invalid_start_date"] = int(bad.sum())
    rejected = df.loc[bad].copy()
    df = df.loc[~bad].copy()

    df["duration_days"] = pd.to_numeric(df.get("duration_days"), errors="coerce")
    end_bad = df["end_date"].isna() | (df["end_date"] < df["start_date"])
    report["end_missing_or_before_start"] = int(end_bad.sum())
    fallback_end = df["start_date"] + pd.to_timedelta((df["duration_days"].fillna(1).clip(lower=1) - 1), unit="D")
    df["end_adjusted"] = end_bad
    df.loc[end_bad, "end_date"] = fallback_end[end_bad]

    for src, dst in (("district_lgd_codes", "district_codes"), ("state_codes", "state_codes_list")):
        parsed = df[src].map(parse_code_list) if src in df.columns else pd.Series([([], 0)] * len(df), index=df.index)
        df[dst] = parsed.map(lambda t: t[0])
        df[dst + "_bad_tokens"] = parsed.map(lambda t: t[1])
    df["district_names"] = df["districts"].map(parse_name_list) if "districts" in df.columns else [[] for _ in range(len(df))]
    df["state_norm"] = df["state"].map(normalize_name)

    sig = ["start_date", "end_date", "state", "districts", "district_lgd_codes"]
    dup = df.duplicated([c for c in sig if c in df.columns], keep="first")
    report["exact_duplicate_events_removed"] = int(dup.sum())
    df = df.loc[~dup]
    if "uei" in df.columns:
        report["duplicate_uei"] = int(df["uei"].duplicated().sum())
    report.update(
        events_clean=int(len(df)),
        date_min=str(df["start_date"].min().date()), date_max=str(df["start_date"].max().date()),
        events_without_district_codes=int((df["district_codes"].map(len) == 0).sum()),
        events_without_state_codes=int((df["state_codes_list"].map(len) == 0).sum()),
        invalid_code_tokens=int(df["district_codes_bad_tokens"].sum()),
        events_with_over_50_districts=int((df["district_codes"].map(len) > 50).sum()),
        events_longer_than_30_days=int((df["duration_days"] > 30).sum()),
    )
    return df.reset_index(drop=True), report, rejected


# ------------------------------------------------------------------------------------------ report
def write_quality_report(sections: dict, out_dir) -> None:
    from pathlib import Path
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(sections, out_dir / "data_quality_report.json")
    lines = ["# Data-quality report", ""]
    for name, rep in sections.items():
        lines += [f"## {name}", ""]
        for k, v in rep.items():
            if isinstance(v, (list, dict)) and len(str(v)) > 300:
                v = f"(see JSON; {len(v)} entries)"
            lines.append(f"- **{k}**: {v}")
        lines.append("")
    (out_dir / "data_quality_report.md").write_text("\n".join(lines), encoding="utf-8")
