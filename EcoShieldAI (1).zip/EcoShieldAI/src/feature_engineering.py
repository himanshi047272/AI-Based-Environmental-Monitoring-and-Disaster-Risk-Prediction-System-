"""Calendar-correct, leakage-free feature engineering.

All features at day t use rainfall observed up to and including day t. The rain cube is a dense
[all calendar days x districts] matrix, so `shift(k)` is *k calendar days*, never "k rows".
Missing rainfall stays NaN (never zero-filled); rolling windows need `min_window_fraction` observed days.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd


def build_rain_cube(rain_clean: pd.DataFrame, codes: np.ndarray | None = None) -> dict:
    """Pivot long rainfall rows into dense arrays on a gap-free daily calendar."""
    df = rain_clean
    if codes is None:
        codes = np.sort(df["district_code"].unique())
    codes = np.asarray(codes, dtype=np.int64)
    dates = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    col = pd.Series(np.arange(len(codes)), index=codes)
    sub = df[df["district_code"].isin(codes)]
    ti = (sub["date"] - dates[0]).dt.days.to_numpy()
    di = col.reindex(sub["district_code"].to_numpy()).to_numpy()
    out = {"dates": dates, "codes": codes}
    for name in ("actual", "normal"):
        arr = np.full((len(dates), len(codes)), np.nan, dtype=np.float32)
        if name in sub.columns:
            arr[ti, di] = sub[name].to_numpy(dtype=np.float32)
        out[name] = arr
    return out


def assert_calendar_cube(dates: pd.DatetimeIndex) -> None:
    if not (np.diff(dates.values).astype("timedelta64[D]").astype(int) == 1).all():
        raise ValueError("Rain cube dates must be consecutive calendar days")


def _roll(df: pd.DataFrame, w: int, frac: float):
    return df.rolling(w, min_periods=max(1, math.ceil(frac * w)))


def feature_names(cfg: dict) -> list[str]:
    f = cfg["features"]
    names = ["rain_0"] + [f"rain_lag{k}" for k in f["lags"]]
    for w in f["windows"]:
        names += [f"rain_sum{w}", f"rain_mean{w}", f"rain_max{w}"]
    names += ["wet_days7", "rain_trend3", "rain_trend7", "rain_intensity3", "days_since_wet",
              "normal_mean7", "rain_vs_normal7", "state_mean_sum3", "state_max_sum3", "state_mean_sum7", "doy_sin", "doy_cos", "monsoon_flag"]
    return names


def _state_aggregate(arr: np.ndarray, state_of_col: np.ndarray, how: str) -> np.ndarray:
    """Same-day aggregate across the districts of one state (spatial context; uses day-t data only)."""
    g = pd.DataFrame(arr).T.groupby(np.asarray(state_of_col))
    agg = (g.mean() if how == "mean" else g.max()).T          # [T, n_states]
    pos = pd.Index(agg.columns).get_indexer(np.asarray(state_of_col))
    return agg.to_numpy()[:, pos]


def compute_features(actual: np.ndarray, normal: np.ndarray, dates: pd.DatetimeIndex, codes: np.ndarray,
                     cfg: dict, mask: np.ndarray | None = None, state_of_col: np.ndarray | None = None) -> pd.DataFrame:
    """Return a DataFrame of features for the cells selected by `mask` [T,D] (all cells if None).
    `state_of_col` gives each district column's state code (used for same-day state-level rainfall context)."""
    assert_calendar_cube(dates)
    f = cfg["features"]
    T, D = actual.shape
    if mask is None:
        mask = np.ones((T, D), dtype=bool)
    ti, di = np.nonzero(mask)
    out: dict[str, np.ndarray] = {
        "date": dates.values[ti], "district_code": codes[di].astype(np.int32)}

    def emit(name, arr):
        out[name] = np.asarray(arr)[ti, di].astype(np.float32)

    A = pd.DataFrame(actual)
    frac = f["min_window_fraction"]
    emit("rain_0", actual)
    for k in f["lags"]:
        emit(f"rain_lag{k}", A.shift(k).to_numpy())          # calendar lag: rows are consecutive days
    sums, maxs = {}, {}
    for w in f["windows"]:
        r = _roll(A, w, frac)
        mean = r.mean()
        sums[w] = (mean * w).to_numpy()
        maxs[w] = r.max().to_numpy()
        emit(f"rain_sum{w}", sums[w])
        emit(f"rain_mean{w}", mean.to_numpy())
        emit(f"rain_max{w}", maxs[w])
    wet = (A >= f["wet_day_mm"]).astype("float32").where(A.notna())
    emit("wet_days7", (wet.rolling(7, min_periods=math.ceil(frac * 7)).sum()).to_numpy())
    emit("rain_trend3", sums[3] - pd.DataFrame(sums[3]).shift(3).to_numpy())
    emit("rain_trend7", sums[7] - pd.DataFrame(sums[7]).shift(7).to_numpy())
    emit("rain_intensity3", maxs[3] / (sums[3] + 1.0))
    # days since last wet day (cap 60); unknown where today's rainfall is unknown
    idx = np.arange(T, dtype=np.float32)[:, None]
    last = np.maximum.accumulate(np.where(np.nan_to_num(actual, nan=0.0) >= f["wet_day_mm"], idx, -1e6), axis=0)
    ds = np.minimum(idx - last, 60.0)
    ds[np.isnan(actual)] = np.nan
    emit("days_since_wet", ds)
    N = pd.DataFrame(normal)
    nm7 = _roll(N, 7, 0.7).mean().to_numpy()
    emit("normal_mean7", nm7)
    emit("rain_vs_normal7", sums[7] - nm7 * 7)
    soc = np.zeros(D, dtype=int) if state_of_col is None else np.asarray(state_of_col)
    emit("state_mean_sum3", _state_aggregate(sums[3], soc, "mean"))
    emit("state_max_sum3", _state_aggregate(sums[3], soc, "max"))
    emit("state_mean_sum7", _state_aggregate(sums[7], soc, "mean"))
    doy = dates.dayofyear.values
    out["doy_sin"] = np.sin(2 * np.pi * doy[ti] / 366.0).astype(np.float32)
    out["doy_cos"] = np.cos(2 * np.pi * doy[ti] / 366.0).astype(np.float32)
    out["monsoon_flag"] = np.isin(dates.month.values[ti], f["monsoon_months"]).astype(np.float32)
    return pd.DataFrame(out)


class DistrictStats:
    """Per-district statistics learned on TRAINING rows only and re-applied at inference."""

    COLUMNS = ["dist_flood_rate", "dist_monsoon_mean_sum7", "dist_p95_sum7", "sum7_over_p95", "sum3_over_p95"]

    def fit(self, train: pd.DataFrame, label_col: str) -> "DistrictStats":
        g = train.groupby("district_code")
        self.flood_rate_ = (g[label_col].mean() * 365.0).astype("float32")           # positives per year-equivalent
        mons = train[train["monsoon_flag"] > 0].groupby("district_code")["rain_sum7"].mean()
        self.monsoon_mean_ = mons.astype("float32")
        self.p95_ = g["rain_sum7"].quantile(0.95).astype("float32")
        self.global_ = {"flood_rate": float(self.flood_rate_.median()), "monsoon_mean": float(self.monsoon_mean_.median()),
                        "p95": float(self.p95_.median())}
        return self

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        code = df["district_code"]
        df["dist_flood_rate"] = code.map(self.flood_rate_).astype("float32")
        df["dist_monsoon_mean_sum7"] = code.map(self.monsoon_mean_).astype("float32")
        df["dist_p95_sum7"] = code.map(self.p95_).astype("float32")
        df["sum7_over_p95"] = (df["rain_sum7"] / (df["dist_p95_sum7"] + 1.0)).astype("float32")
        df["sum3_over_p95"] = (df["rain_sum3"] / (df["dist_p95_sum7"] + 1.0)).astype("float32")
        return df   # districts unseen in training keep NaN -> imputed by the training-fitted imputer


import re as _re

_LEAK_RE = _re.compile(r"(^y\d)|label|future|onset|target|episode|^post_|_post_")


def leakage_prone(columns: list[str]) -> list[str]:
    """Names that look target-derived (y1/y3..., label, future, onset, target, episode, post-event)."""
    return [c for c in columns if _LEAK_RE.search(c.lower())]
