"""District boundary loading, verified code join, and the choropleth. No boundary file is bundled: the user supplies
one (with LGD district codes) and this module REPORTS what joined and what did not. Nothing is guessed."""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

RISK_COLORS = {"Low": "#2E9E5B", "Moderate": "#F2C94C", "High": "#F2994A", "Very high": "#D64545", "Unavailable": "#B8BEC6"}
RISK_ORDER = ["Low", "Moderate", "High", "Very high", "Unavailable"]


def _code_of(value) -> int | None:
    m = re.search(r"\d+", str(value)) if value is not None else None
    return int(m.group()) if m else None


def load_geojson(path, code_property: str) -> tuple[dict | None, dict]:
    """Return (geojson, status). status['ok'] False => dashboard shows the 'boundaries missing' state."""
    p = Path(path)
    if not p.exists():
        return None, {"ok": False, "message": f"District boundary file not found: {p}"}
    try:
        gj = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return None, {"ok": False, "message": f"Could not read GeoJSON: {exc}"}
    feats = gj.get("features") if isinstance(gj, dict) else None
    if not feats:
        return None, {"ok": False, "message": "GeoJSON has no features"}
    missing = 0
    for f in feats:
        props = f.setdefault("properties", {})
        code = _code_of(props.get(code_property))
        props["_code"] = code
        missing += code is None
    if missing == len(feats):
        return None, {"ok": False, "message": f"No feature has a '{code_property}' property; set paths.geojson_code_property"}
    return gj, {"ok": True, "n_features": len(feats), "features_without_code": missing, "message": ""}


def join_report(gj: dict, data_codes, master: pd.DataFrame | None = None) -> dict:
    geo_codes = {f["properties"]["_code"] for f in gj["features"] if f["properties"].get("_code") is not None}
    data = {int(c) for c in data_codes}
    codes_seen: dict[int, int] = {}
    for f in gj["features"]:
        c = f["properties"].get("_code")
        if c is not None:
            codes_seen[c] = codes_seen.get(c, 0) + 1
    return {"matched": len(geo_codes & data), "districts_without_geometry": sorted(data - geo_codes),
            "geometries_without_data": sorted(geo_codes - data),
            "duplicate_geometry_codes": sorted(c for c, n in codes_seen.items() if n > 1)}


def _ring_centroid(ring) -> tuple[float, float, float]:
    xy = np.asarray(ring, float)
    x, y = xy[:, 0], xy[:, 1]
    cross = x[:-1] * y[1:] - x[1:] * y[:-1]
    a = cross.sum() / 2
    if abs(a) < 1e-12:
        return float(x.mean()), float(y.mean()), 0.0
    return float(((x[:-1] + x[1:]) * cross).sum() / (6 * a)), float(((y[:-1] + y[1:]) * cross).sum() / (6 * a)), abs(a)


def feature_centroids(gj: dict) -> dict[int, tuple[float, float]]:
    """code -> (lat, lon) using the largest polygon's area-weighted centroid."""
    out = {}
    for f in gj["features"]:
        c = f["properties"].get("_code")
        g = f.get("geometry") or {}
        if c is None or not g:
            continue
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]] if g["type"] == "Polygon" else []
        best = max((_ring_centroid(p[0]) for p in polys if p), key=lambda t: t[2], default=None)
        if best:
            out[c] = (best[1], best[0])
    return out


def bounds_center(gj: dict) -> tuple[float, float]:
    lons, lats = [], []

    def walk(o):
        if isinstance(o, (list, tuple)) and o and isinstance(o[0], (int, float)):
            lons.append(o[0]); lats.append(o[1])
        elif isinstance(o, (list, tuple)):
            for i in o:
                walk(i)
    for f in gj["features"]:
        walk((f.get("geometry") or {}).get("coordinates", []))
    return (float(np.mean(lats)), float(np.mean(lons))) if lats else (22.5, 79.0)


def build_risk_map(gj: dict, df: pd.DataFrame, selected_code: int | None = None, height: int = 560,
                   dark: bool = False, value_col: str = "risk_category", hover_cols=None):
    """Plotly choropleth. `df` needs district_code + risk_category (+ hover columns). Categories are discrete colours."""
    import plotly.graph_objects as go
    d = df.copy()
    d["_code"] = d["district_code"].astype(int)
    fig = go.Figure()
    for cat in RISK_ORDER:
        sub = d[d[value_col] == cat]
        if sub.empty:
            continue
        hover = sub.get("hover_text", sub["district_name"])
        fig.add_trace(go.Choroplethmap(
            geojson=gj, featureidkey="properties._code", locations=sub["_code"], z=np.ones(len(sub)),
            colorscale=[[0, RISK_COLORS[cat]], [1, RISK_COLORS[cat]]], showscale=False, name=cat, showlegend=True,
            text=hover, hovertemplate="%{text}<extra></extra>", marker_opacity=0.82,
            marker_line_width=0.3, marker_line_color="#FFFFFF" if not dark else "#1B2A36"))
    if selected_code is not None:
        fig.add_trace(go.Choroplethmap(
            geojson=gj, featureidkey="properties._code", locations=[int(selected_code)], z=[1],
            colorscale=[[0, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0)"]], showscale=False, showlegend=False, hoverinfo="skip",
            marker_line_width=3, marker_line_color="#FF7A1A"))
    lat, lon = bounds_center(gj)
    fig.update_layout(map_style="carto-darkmatter" if dark else "carto-positron", map_center={"lat": lat, "lon": lon}, map_zoom=3.4,
                      margin=dict(l=0, r=0, t=0, b=0), height=height, paper_bgcolor="rgba(0,0,0,0)",
                      legend=dict(orientation="h", yanchor="bottom", y=0.01, xanchor="left", x=0.01,
                                  bgcolor="rgba(255,255,255,0.85)" if not dark else "rgba(15,26,34,0.85)",
                                  font=dict(color="#14213D" if not dark else "#E6EEF3")))
    return fig
