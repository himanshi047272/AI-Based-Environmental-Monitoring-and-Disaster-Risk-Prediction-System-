"""Match flood events to rainfall districts by LGD code (preferred) with a documented, conservative name fallback."""
from __future__ import annotations

import pandas as pd

from .utils import normalize_name


def build_district_master(rain_clean: pd.DataFrame) -> pd.DataFrame:
    """One row per district_code. Raises if a code maps to several names/states (should already be removed)."""
    m = (rain_clean.groupby("district_code")
         .agg(district_name=("district_name", "first"), state_code=("state_code", "first"),
              state_name=("state_name", "first"), district_norm=("district_norm", "first"),
              state_norm=("state_norm", "first"),
              n_names=("district_name", "nunique"), n_states=("state_code", "nunique")).reset_index())
    bad = m[(m.n_names > 1) | (m.n_states > 1)]
    if len(bad):
        raise ValueError(f"District codes with several names/states in rainfall data: {bad.district_code.tolist()[:10]}")
    return m.drop(columns=["n_names", "n_states"])


def match_events(events: pd.DataFrame, master: pd.DataFrame, ambiguous_codes: list[int] | None = None
                 ) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    """Return (matched, report, detail).

    matched: one row per (event, district) with `match_source` in {lgd_code, name_fallback}.
    detail:  one row per attempted (event, token) with a `status`, for the mapping report CSV.
    Rules
      1. A listed LGD code must exist in the rainfall master (else `invalid_code`).
      2. Codes of ambiguous districts are never matched (`ambiguous_code`).
      3. If the event lists state codes, the district's state must be among them (else `state_mismatch`) –
         this prevents matches caused by stray/mis-typed codes.
      4. Events with NO usable code are matched by exact normalised district name inside the event's states
         (`name_fallback`); ambiguous or unknown names stay unmatched. Nothing is forced.
    """
    ambiguous = set(ambiguous_codes or [])
    by_code = master.set_index("district_code")
    valid_codes = set(by_code.index)
    rows, detail = [], []

    name_index: dict[tuple[str, int], list[int]] = {}
    name_index_nostate: dict[str, list[int]] = {}
    for r in master.itertuples():
        name_index.setdefault((r.district_norm, int(r.state_code)), []).append(int(r.district_code))
        name_index_nostate.setdefault(r.district_norm, []).append(int(r.district_code))
    state_by_norm = master.groupby("state_norm")["state_code"].first().to_dict()

    for ev in events.itertuples():
        states = set(ev.state_codes_list)
        if not states and ev.state_norm in state_by_norm:
            states = {int(state_by_norm[ev.state_norm])}
        code_hits = 0
        for code in ev.district_codes:
            status = "matched"
            if code in ambiguous:
                status = "ambiguous_code"
            elif code not in valid_codes:
                status = "invalid_code"
            elif states and int(by_code.at[code, "state_code"]) not in states:
                status = "state_mismatch"
            detail.append((ev.Index, ev.uei if hasattr(ev, "uei") else ev.Index, "code", str(code), status))
            if status == "matched":
                rows.append((ev.Index, code, "lgd_code"))
                code_hits += 1
        if code_hits == 0:
            for nm in ev.district_names:
                key = normalize_name(nm)
                cands: list[int] = []
                if key:
                    if states:
                        for s in states:
                            cands += name_index.get((key, int(s)), [])
                    else:
                        cands = name_index_nostate.get(key, [])
                cands = [c for c in dict.fromkeys(cands) if c not in ambiguous]
                if len(cands) == 1:
                    rows.append((ev.Index, cands[0], "name_fallback"))
                    detail.append((ev.Index, getattr(ev, "uei", ev.Index), "name", nm, "matched_name_fallback"))
                else:
                    detail.append((ev.Index, getattr(ev, "uei", ev.Index), "name", nm,
                                   "ambiguous_name" if len(cands) > 1 else "unmatched_name"))

    matched = pd.DataFrame(rows, columns=["event_idx", "district_code", "match_source"])
    matched = matched.drop_duplicates(["event_idx", "district_code"])
    matched = matched.join(events[["uei", "start_date", "end_date", "duration_days", "state"]], on="event_idx")
    matched["district_code"] = matched["district_code"].astype("int32")
    det = pd.DataFrame(detail, columns=["event_idx", "uei", "token_type", "token", "status"])

    n_events = len(events)
    ev_matched = matched["event_idx"].nunique()
    report = {
        "events_total": n_events,
        "events_with_at_least_one_match": int(ev_matched),
        "events_unmatched": int(n_events - ev_matched),
        "event_district_pairs_matched": int(len(matched)),
        "pairs_by_source": matched["match_source"].value_counts().to_dict(),
        "token_status_counts": det["status"].value_counts().to_dict(),
        "invalid_codes_sample": sorted(det.loc[det.status == "invalid_code", "token"].astype(int).unique().tolist())[:50],
        "n_invalid_codes_unique": int(det.loc[det.status == "invalid_code", "token"].nunique()),
        "rainfall_districts_total": int(len(master)),
        "rainfall_districts_with_any_event": int(matched["district_code"].nunique()),
        "one_to_many_events_matching_over_50_districts": int((matched.groupby("event_idx").size() > 50).sum()),
    }
    return matched, report, det
