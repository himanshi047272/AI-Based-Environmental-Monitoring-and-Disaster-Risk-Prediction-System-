"""Flood-label generation (kept separate from training so it can be inspected/tested alone).

Definition (documented, do not change silently)
-----------------------------------------------
* An *episode* is a recorded flood event in one district. Events of the same district that overlap or touch
  (start <= previous_end + 1 day) are MERGED into one episode, so one flood is never counted twice.
* The episode ONSET is its earliest start date. Only onsets are prediction targets.
* label_h[t, d] = 1  iff an onset of district d falls in (t, t+h] days, i.e. t+1 ... t+h.
  Features at time t may use data up to and including day t only.
* A district-day with no recorded onset is NOT a confirmed flood-free day (the inventory is incomplete).
  Negatives are therefore "no recorded onset". Evaluation is "against recorded events".
* Rows where the district is already inside a recorded episode on day t ("in-event") are not scored; the question
  "will a flood begin?" is not well-posed there. The in-event mask is capped at `max_active_days` per episode.
* Labels are UNKNOWN (excluded) when t+h is later than the last inventory date.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def merge_episodes(matched: pd.DataFrame, max_active_days: int = 30) -> pd.DataFrame:
    rows = []
    m = matched.dropna(subset=["start_date"]).sort_values(["district_code", "start_date"])
    one = pd.Timedelta(days=1)
    for code, g in m.groupby("district_code", sort=True):
        cur_s = cur_e = None
        n = 0
        for s, e in zip(g["start_date"], g["end_date"].fillna(g["start_date"])):
            e = max(e, s)
            if cur_s is None:
                cur_s, cur_e, n = s, e, 1
            elif s <= cur_e + one:
                cur_e, n = max(cur_e, e), n + 1
            else:
                rows.append((code, cur_s, cur_e, n))
                cur_s, cur_e, n = s, e, 1
        if cur_s is not None:
            rows.append((code, cur_s, cur_e, n))
    ep = pd.DataFrame(rows, columns=["district_code", "onset", "end", "n_events_merged"])
    ep["onset"] = ep["onset"].dt.normalize()
    ep["end"] = ep["end"].dt.normalize()
    ep["active_end"] = np.minimum(ep["end"], ep["onset"] + pd.Timedelta(days=max_active_days - 1))
    return ep


def build_event_matrices(episodes: pd.DataFrame, dates: pd.DatetimeIndex, codes: np.ndarray):
    """Return (onset[T,D], active[T,D]) boolean matrices aligned with the rain cube."""
    T, D = len(dates), len(codes)
    onset = np.zeros((T, D), dtype=bool)
    active = np.zeros((T, D), dtype=bool)
    col = {int(c): i for i, c in enumerate(codes)}
    d0 = dates[0]
    for r in episodes.itertuples():
        j = col.get(int(r.district_code))
        if j is None:
            continue
        s = (r.onset - d0).days
        e = (r.active_end - d0).days
        if e < 0 or s >= T:
            continue
        if s >= 0:
            onset[s, j] = True
        active[max(s, 0):min(e, T - 1) + 1, j] = True
    return onset, active


def horizon_labels(onset: np.ndarray, h: int) -> np.ndarray:
    """y[t,d] = any onset in days t+1..t+h (tail rows where t+h exceeds the cube are returned False; mask them)."""
    T = onset.shape[0]
    c = np.cumsum(onset, axis=0, dtype=np.int32)
    end = np.minimum(np.arange(T) + h, T - 1)
    return (c[end] - c) > 0


def label_known_mask(dates: pd.DatetimeIndex, h: int, inventory_end: pd.Timestamp) -> np.ndarray:
    """True where the full label window t+1..t+h lies inside the inventory's time coverage."""
    return np.asarray(dates + pd.Timedelta(days=h) <= pd.Timestamp(inventory_end))


def coverage_tables(episodes: pd.DataFrame, master: pd.DataFrame, rain_start: pd.Timestamp,
                    inventory_end: pd.Timestamp, min_per_state: int, surge_factor: float):
    ep = episodes.merge(master[["district_code", "state_code", "state_name"]], on="district_code", how="left")
    ep = ep[(ep.onset >= rain_start) & (ep.onset <= inventory_end)]
    st = (ep.groupby(["state_code", "state_name"]).agg(
        episodes=("onset", "size"), districts_with_events=("district_code", "nunique"),
        first_onset=("onset", "min"), last_onset=("onset", "max")).reset_index())
    all_states = master[["state_code", "state_name"]].drop_duplicates()
    st = all_states.merge(st, on=["state_code", "state_name"], how="left")
    st["episodes"] = st["episodes"].fillna(0).astype(int)
    st["low_inventory_coverage"] = st["episodes"] < min_per_state
    yr = ep.groupby(ep.onset.dt.year).size().rename("episodes").reset_index().rename(columns={"onset": "year"})
    med = float(yr["episodes"].median()) if len(yr) else 0.0
    yr["reporting_surge"] = yr["episodes"] > surge_factor * med if med else False
    return st, yr


def positive_rate_tables(y: np.ndarray, valid: np.ndarray, dates: pd.DatetimeIndex, codes: np.ndarray,
                         master: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Label counts and positive rates by year, month, state and district (valid rows only)."""
    yv = (y & valid)
    out = {}

    def tab(keys, n_valid, n_pos, name):
        df = pd.DataFrame({name: keys, "valid_rows": n_valid, "positives": n_pos})
        df["positive_rate"] = df["positives"] / df["valid_rows"].replace(0, np.nan)
        return df

    years = dates.year.values
    uy = np.unique(years)
    out["year"] = tab(uy, [int(valid[years == u].sum()) for u in uy], [int(yv[years == u].sum()) for u in uy], "year")
    months = dates.month.values
    um = np.arange(1, 13)
    out["month"] = tab(um, [int(valid[months == u].sum()) for u in um], [int(yv[months == u].sum()) for u in um], "month")
    dist = tab(codes, valid.sum(0), yv.sum(0), "district_code").merge(
        master[["district_code", "district_name", "state_code", "state_name"]], on="district_code", how="left")
    out["district"] = dist
    out["state"] = (dist.groupby(["state_code", "state_name"])[["valid_rows", "positives"]].sum().reset_index()
                    .assign(positive_rate=lambda d: d.positives / d.valid_rows.replace(0, np.nan)))
    return out
