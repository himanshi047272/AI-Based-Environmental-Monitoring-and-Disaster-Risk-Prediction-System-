"""Load the saved production classifier and score districts. The dashboard never retrains."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime

import joblib
import numpy as np
import pandas as pd

from .feature_engineering import compute_features
from .utils import latest_version_dir, load_json, resolve_path, save_json

log = logging.getLogger("ecoshield")
CATEGORIES = ["Low", "Moderate", "High", "Very high"]
UNAVAILABLE = "Unavailable"


class ModelNotFoundError(FileNotFoundError):
    pass


@dataclass
class ModelBundle:
    pipeline: object
    stats: object
    meta: dict

    @property
    def features(self) -> list[str]:
        return self.meta["features"]

    @property
    def version(self) -> str:
        return self.meta["model_version"]


def load_production_model(cfg: dict, horizon: int, version_dir=None) -> ModelBundle:
    """Load models/<LATEST>/h<horizon>. Raises ModelNotFoundError with instructions if nothing has been trained."""
    models_dir = resolve_path(cfg, "models_dir")
    vdir = version_dir or latest_version_dir(models_dir)
    if vdir is None:
        raise ModelNotFoundError("No trained model found (models/LATEST missing). Run: python -m src.pipeline train")
    hd = vdir / f"h{horizon}"
    if not (hd / "model.joblib").exists():
        raise ModelNotFoundError(f"Model files for horizon {horizon} missing in {vdir}")
    return ModelBundle(joblib.load(hd / "model.joblib"), joblib.load(hd / "district_stats.joblib"), load_json(hd / "meta.json"))


def validate_feature_frame(df: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    """Fail loudly on missing columns instead of silently filling; returns columns in training order."""
    missing = [f for f in features if f not in df.columns]
    if missing:
        raise ValueError(f"Classifier input is missing required feature columns: {missing}")
    return df[features]


def assign_risk_category(scores, cutoffs: dict) -> np.ndarray:
    s = np.asarray(scores, float)
    cat = np.full(s.shape, UNAVAILABLE, dtype=object)
    ok = np.isfinite(s)
    cat[ok & (s < cutoffs["moderate"])] = "Low"
    cat[ok & (s >= cutoffs["moderate"]) & (s < cutoffs["high"])] = "Moderate"
    cat[ok & (s >= cutoffs["high"]) & (s < cutoffs["very_high"])] = "High"
    cat[ok & (s >= cutoffs["very_high"])] = "Very high"
    return cat


def score_frame(bundle: ModelBundle, feats: pd.DataFrame) -> np.ndarray:
    """feats must already contain every training feature (district statistics are applied here)."""
    f = bundle.stats.transform(feats)
    X = validate_feature_frame(f, bundle.features)
    return bundle.pipeline.predict_proba(X)[:, 1].astype(float)


# --------------------------------------------------------------------------------------- cube helpers
def load_cube(cfg: dict) -> dict:
    z = np.load(resolve_path(cfg, "processed_dir", "rain_cube.npz"))
    dates = pd.DatetimeIndex(z["dates"].astype("datetime64[D]"))
    return {"dates": dates, "codes": z["codes"], "actual": z["actual"], "normal": z["normal"]}


def latest_feasible_index(actual: np.ndarray, min_fraction: float) -> int:
    """Last day on which at least `min_fraction` of districts have an observed rainfall value."""
    frac = np.isfinite(actual).mean(axis=1)
    ok = np.flatnonzero(frac >= min_fraction)
    if len(ok) == 0:
        raise ValueError("No date has enough observed rainfall")
    return int(ok[-1])


def run_snapshot_predictions(cfg: dict) -> pd.DataFrame:
    """Score every district for the most recent feasible as-of dates (HISTORICAL data; not a live forecast)."""
    cube = load_cube(cfg)
    dates, codes = cube["dates"], cube["codes"]
    master = pd.read_csv(resolve_path(cfg, "processed_dir", "district_master.csv"))
    scfg = cfg["snapshots"]
    last = latest_feasible_index(cube["actual"], scfg["min_feature_complete_fraction"])
    idxs = np.arange(max(0, last - scfg["n_days"] + 1), last + 1)
    mask = np.zeros(cube["actual"].shape, dtype=bool)
    mask[idxs, :] = True
    state_of_col = master.set_index("district_code").loc[codes, "state_code"].to_numpy()
    feats = compute_features(cube["actual"], cube["normal"], dates, codes, cfg, mask, state_of_col)
    info = master.set_index("district_code")
    now = datetime.now().isoformat(timespec="seconds")
    frames, version = [], None
    for h in cfg["labels"]["horizons"]:
        b = load_production_model(cfg, h)
        version = b.version
        scores = score_frame(b, feats)
        d = feats[["date", "district_code", "rain_0", "rain_sum3", "rain_sum7", "rain_sum14"]].copy()
        d["risk_score"] = scores
        reason = np.where(info.loc[d.district_code, "insufficient_history"].to_numpy(), "insufficient rainfall history",
                          np.where(~np.isfinite(d["rain_0"]) | ~np.isfinite(d["rain_sum7"]), "recent rainfall missing", ""))
        invalid = reason != ""
        d.loc[invalid, "risk_score"] = np.nan
        d["prediction_valid"] = ~invalid
        d["unavailable_reason"] = reason
        d["risk_category"] = assign_risk_category(d["risk_score"], b.meta["risk_cutoffs"])
        d["above_alert_threshold"] = d["risk_score"] >= b.meta["decision_threshold"]
        d["horizon_days"] = h
        d["model_version"] = b.version
        frames.append(d)
    out = pd.concat(frames, ignore_index=True).rename(columns={"date": "as_of_date"})
    out = out.merge(master[["district_code", "district_name", "state_code", "state_name", "low_inventory_coverage"]],
                    on="district_code", how="left")
    out["data_mode"] = "historical"
    out["generated_at"] = now
    pdir = resolve_path(cfg, "predictions_dir", create=True)
    out.to_csv(pdir / "snapshot_predictions.csv", index=False)

    hist_days = scfg["recent_history_days"]
    lo = max(0, last - hist_days + 1)
    rec = pd.DataFrame(cube["actual"][lo:last + 1], index=dates[lo:last + 1], columns=codes).rename_axis("date")
    rec = rec.reset_index().melt("date", var_name="district_code", value_name="actual_mm")
    rec.to_csv(pdir / "recent_rainfall.csv", index=False)
    save_json({"data_mode": "historical", "latest_as_of_date": str(dates[last].date()),
               "as_of_dates": [str(dates[i].date()) for i in idxs], "model_version": version, "generated_at": now,
               "note": "Snapshots are computed from historical rainfall records and are NOT current forecasts."},
              pdir / "snapshot_meta.json")
    log.info("Wrote %d prediction rows for as-of %s .. %s", len(out), dates[idxs[0]].date(), dates[last].date())
    return out
