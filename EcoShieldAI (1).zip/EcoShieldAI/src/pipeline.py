"""Command-line pipeline:  python -m src.pipeline {prepare|train|forecast|predict|all}"""
from __future__ import annotations

import argparse
import logging
import time

import numpy as np
import pandas as pd

from . import data_cleaning as dc
from . import data_loader as dl
from . import district_matching as dm
from . import feature_engineering as fe
from . import label_generation as lg
from .utils import load_config, resolve_path, save_json, setup_logging

log = logging.getLogger("ecoshield")


def prepare(cfg: dict) -> dict:
    """Load -> audit/clean -> match districts -> labels -> features. Writes reports + processed data."""
    t0 = time.time()
    reports_dir = resolve_path(cfg, "reports_dir", create=True)
    processed = resolve_path(cfg, "processed_dir", create=True)
    lcfg = cfg["labels"]

    rain_raw, rain_info = dl.load_rainfall_raw(cfg)
    rain, rain_rep = dc.clean_rainfall(rain_raw, cfg)
    del rain_raw
    flood_raw, flood_info = dl.load_floods_raw(cfg)
    events, flood_rep, flood_rej = dc.clean_floods(flood_raw)
    rain_rep.update(encoding=rain_info["encoding"], malformed_rows=rain_info["malformed_rows"])
    flood_rep.update(encoding=flood_info["encoding"], malformed_rows=flood_info["malformed_rows"])

    master = dm.build_district_master(rain)
    matched, map_rep, map_detail = dm.match_events(events, master, rain_rep["ambiguous_district_codes"])
    map_rep["ambiguous_rainfall_codes_excluded"] = rain_rep["ambiguous_code_detail"]
    save_json(map_rep, reports_dir / "district_mapping_report.json")
    map_detail.to_csv(reports_dir / "district_mapping_detail.csv", index=False)
    flood_rej.astype(str).to_csv(reports_dir / "rejected_flood_rows.csv", index=False)

    # ---- cube (dense calendar grid) -------------------------------------------------------------
    cube = fe.build_rain_cube(rain, master["district_code"].to_numpy())
    dates, codes = cube["dates"], cube["codes"]
    insufficient = set(rain_rep["insufficient_history_districts"])
    pd.DataFrame({"district_code": sorted(insufficient)}).merge(master, on="district_code", how="left").to_csv(
        reports_dir / "insufficient_history_districts.csv", index=False)

    # ---- labels ---------------------------------------------------------------------------------
    in_window = matched[matched["end_date"] >= dates[0] - pd.Timedelta(days=60)]
    episodes = lg.merge_episodes(in_window, lcfg["max_active_days"])
    inventory_end = matched["start_date"].max()
    onset, active = lg.build_event_matrices(episodes, dates, codes)
    cov_state, cov_year = lg.coverage_tables(episodes, master, dates[0], inventory_end,
                                             lcfg["min_episodes_per_state"], lcfg["reporting_surge_factor"])
    cov_state.to_csv(reports_dir / "inventory_coverage_by_state.csv", index=False)
    cov_year.to_csv(reports_dir / "inventory_coverage_by_year.csv", index=False)
    low_states = set(cov_state.loc[cov_state.low_inventory_coverage, "state_code"].astype(int))
    state_of_col = master.set_index("district_code").loc[codes, "state_code"].to_numpy()
    cols_ok = ~np.isin(codes, list(insufficient))
    if lcfg["exclude_low_coverage_states"]:
        cols_ok &= ~np.isin(state_of_col, list(low_states))

    primary = lcfg["primary_horizon"]
    known = lg.label_known_mask(dates, primary, inventory_end)
    valid = known[:, None] & cols_ok[None, :] & ~np.isnan(cube["actual"])
    if lcfg["exclude_in_event"]:
        valid &= ~active
    Y = {h: lg.horizon_labels(onset, h) for h in lcfg["horizons"]}

    # ---- features on valid cells -----------------------------------------------------------------
    X = fe.compute_features(cube["actual"], cube["normal"], dates, codes, cfg, valid, state_of_col)
    ti, di = np.nonzero(valid)
    nan_core = X["rain_sum7"].isna().to_numpy()
    for h, y in Y.items():
        X[f"y{h}"] = y[ti, di].astype(np.int8)
    X = X.loc[~nan_core].reset_index(drop=True)
    valid[ti[nan_core], di[nan_core]] = False
    log.info("Model frame: %s rows (%s dropped: incomplete 7-day window)", f"{len(X):,}", int(nan_core.sum()))
    X.to_pickle(processed / "model_frame.pkl")

    tabs = lg.positive_rate_tables(Y[primary], valid, dates, codes, master)
    for k, v in tabs.items():
        v.to_csv(reports_dir / f"label_positive_rate_by_{k}.csv", index=False)

    np.savez_compressed(processed / "rain_cube.npz", dates=dates.values.astype("datetime64[D]").astype(np.int64),
                        codes=codes, actual=cube["actual"], normal=cube["normal"])
    master.assign(insufficient_history=master.district_code.isin(insufficient),
                  low_inventory_coverage=master.state_code.isin(low_states)).to_csv(processed / "district_master.csv", index=False)
    episodes.to_csv(processed / "flood_episodes.csv", index=False)

    label_rep = {
        "definition": "label_h = recorded flood-episode onset within (t, t+h] days; episodes merged when overlapping/adjacent; "
                      "in-event rows excluded; unknown-label tail excluded; absence of a record is NOT confirmed flood-free",
        "episodes": int(len(episodes)), "inventory_last_onset": str(inventory_end.date()),
        "rainfall_range": [str(dates[0].date()), str(dates[-1].date())],
        "rows_model_frame": int(len(X)), "positives_by_horizon": {f"h{h}": int(X[f"y{h}"].sum()) for h in Y},
        "positive_rate_primary": float(X[f"y{primary}"].mean()),
        "rows_dropped_incomplete_7d_window": int(nan_core.sum()),
        "low_inventory_coverage_states": cov_state.loc[cov_state.low_inventory_coverage, "state_name"].tolist(),
        "reporting_surge_years": cov_year.loc[cov_year.reporting_surge, "year"].astype(int).tolist(),
        "max_active_days": lcfg["max_active_days"], "excluded_districts_insufficient_history": sorted(map(int, insufficient)),
    }
    save_json(label_rep, reports_dir / "label_report.json")
    dc.write_quality_report({"rainfall": {k: v for k, v in rain_rep.items() if k != "rejected_sample"},
                             "flood_inventory": flood_rep, "district_matching": {k: v for k, v in map_rep.items()
                                                                                  if k != "ambiguous_rainfall_codes_excluded"},
                             "labels": label_rep}, reports_dir)
    log.info("prepare finished in %.1fs", time.time() - t0)
    return label_rep


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m src.pipeline")
    ap.add_argument("stage", choices=["prepare", "train", "forecast", "predict", "all"])
    ap.add_argument("--config", default=None)
    ap.add_argument("--quick", action="store_true", help="train on a district subset (smoke test only)")
    ap.add_argument("--max-districts", type=int, default=None, help="forecast: limit districts (runtime)")
    a = ap.parse_args(argv)
    setup_logging()
    cfg = load_config(a.config)
    if a.stage in ("prepare", "all"):
        prepare(cfg)
    if a.stage in ("train", "all"):
        from .train_models import run_training
        run_training(cfg, quick=a.quick)
    if a.stage in ("forecast", "all"):
        from .rainfall_forecasting import run_forecasting
        if a.max_districts:
            cfg["forecast"]["max_districts"] = a.max_districts
        run_forecasting(cfg)
    if a.stage in ("predict", "all"):
        from .flood_risk_prediction import run_snapshot_predictions
        run_snapshot_predictions(cfg)


if __name__ == "__main__":
    main()
