"""Chronological training, imbalance handling (class weights / random oversampling / SMOTE), model comparison,
versioned artifact saving. Resampling touches TRAINING data only and happens AFTER imputation/scaling."""
from __future__ import annotations

import gc
import logging
import platform
import time
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import (ExtraTreesClassifier, GradientBoostingClassifier, HistGradientBoostingClassifier,
                              RandomForestClassifier)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .evaluate_models import best_f1, classification_metrics, select_threshold
from .feature_engineering import DistrictStats, feature_names
from .feature_selection import select_features
from .utils import new_version_dir, resolve_path, save_json

log = logging.getLogger("ecoshield")
CALIBRATION_NOTE = ("Scores are uncalibrated classifier outputs (training used class re-weighting/negative subsampling). "
                    "They rank relative risk and must not be read as probabilities.")


# ----------------------------------------------------------------------------------------- splitting
def chronological_split(dates, fractions=(0.70, 0.15, 0.15), purge_days: int = 3):
    """Time-ordered split on unique calendar dates, with a `purge_days` gap before each boundary so that label
    windows (t, t+h] of earlier rows never reach into the next period. Returns (train, val, test, info)."""
    d = pd.to_datetime(pd.Series(np.asarray(dates)))
    ud = np.sort(d.unique())
    n = len(ud)
    i1, i2 = int(n * fractions[0]), int(n * (fractions[0] + fractions[1]))
    gap = pd.Timedelta(days=purge_days)
    t_end, v_start, v_end, te_start = (pd.Timestamp(ud[i1 - 1]), pd.Timestamp(ud[i1]),
                                       pd.Timestamp(ud[i2 - 1]), pd.Timestamp(ud[i2]))
    train = (d <= t_end - gap).to_numpy()
    val = ((d >= v_start) & (d <= v_end - gap)).to_numpy()
    test = (d >= te_start).to_numpy()
    info = {"train_start": str(d.min().date()), "train_end": str((t_end - gap).date()),
            "val_start": str(v_start.date()), "val_end": str((v_end - gap).date()),
            "test_start": str(te_start.date()), "test_end": str(d.max().date()), "purge_days": purge_days}
    return train, val, test, info


# --------------------------------------------------------------------------------------- resampling
def subsample_negatives(y: np.ndarray, per_positive: int, rng) -> np.ndarray:
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)
    n_neg = min(len(neg), max(1, per_positive) * max(1, len(pos)))
    keep = np.concatenate([pos, rng.choice(neg, n_neg, replace=False)])
    keep.sort()
    return keep


def random_oversample(X: np.ndarray, y: np.ndarray, target_ratio: float, rng):
    pos = np.flatnonzero(y == 1)
    n_neg = int((y == 0).sum())
    need = int(target_ratio * n_neg) - len(pos)
    if need <= 0 or len(pos) == 0:
        return X, y
    extra = rng.choice(pos, need, replace=True)
    return np.vstack([X, X[extra]]), np.concatenate([y, y[extra]])


def smote(X: np.ndarray, y: np.ndarray, target_ratio: float, k: int, rng, categorical_idx=()):
    """SMOTE on the minority class (SMOTE-NC style for binary/categorical columns: a synthetic row copies the
    category of its nearer parent instead of interpolating). Apply to TRAINING arrays only."""
    pos_idx = np.flatnonzero(y == 1)
    n_neg = int((y == 0).sum())
    need = int(target_ratio * n_neg) - len(pos_idx)
    if need <= 0 or len(pos_idx) < 2:
        return X, y
    P = X[pos_idx]
    kk = min(k, len(P) - 1)
    sd = P.std(axis=0)
    sd[sd == 0] = 1.0
    nn = NearestNeighbors(n_neighbors=kk + 1).fit(P / sd)
    nbrs = nn.kneighbors(P / sd, return_distance=False)[:, 1:]
    base = rng.integers(0, len(P), need)
    nb = nbrs[base, rng.integers(0, kk, need)]
    lam = rng.random((need, 1)).astype(P.dtype)
    synth = P[base] + lam * (P[nb] - P[base])
    for c in categorical_idx:
        synth[:, c] = np.where(lam[:, 0] < 0.5, P[base, c], P[nb, c])
    return np.vstack([X, synth]), np.concatenate([y, np.ones(need, dtype=y.dtype)])


# ------------------------------------------------------------------------------------------ models
def _optional(name):
    try:
        return __import__(name)
    except Exception:  # noqa: BLE001
        return None


def model_specs(seed: int, quick: bool = False) -> dict:
    n_trees = 40 if quick else 100
    specs = {
        "logistic_regression": dict(scale=True, grid=[{"C": 0.1}, {"C": 1.0}]),
        "random_forest": dict(scale=False, grid=[{"max_depth": 10}, {"max_depth": 16}]),
        "extra_trees": dict(scale=False, grid=[{"max_depth": 12}, {"max_depth": 18}]),
        "hist_gradient_boosting": dict(scale=False, grid=[{"learning_rate": 0.05, "max_leaf_nodes": 31},
                                                          {"learning_rate": 0.1, "max_leaf_nodes": 15}]),
        "gradient_boosting": dict(scale=False, grid=[{"max_depth": 3}]),
    }
    if _optional("xgboost"):
        specs["xgboost"] = dict(scale=False, grid=[{"max_depth": 4, "learning_rate": 0.1}, {"max_depth": 6, "learning_rate": 0.05}])
    if _optional("lightgbm"):
        specs["lightgbm"] = dict(scale=False, grid=[{"num_leaves": 31, "learning_rate": 0.05}])
    if quick:
        for s in specs.values():
            s["grid"] = s["grid"][:1]
    for s in specs.values():
        s["n_trees"] = n_trees
    return specs


def make_estimator(name: str, params: dict, strategy: str, seed: int, n_trees: int, pos_weight: float):
    cw = "balanced" if strategy == "class_weight" else None
    if name == "logistic_regression":
        return LogisticRegression(C=params["C"], class_weight=cw, max_iter=400, random_state=seed)
    if name == "random_forest":
        return RandomForestClassifier(n_estimators=n_trees, max_depth=params["max_depth"], min_samples_leaf=10,
                                      max_features="sqrt", max_samples=0.5, class_weight=cw, n_jobs=1, random_state=seed)
    if name == "extra_trees":
        return ExtraTreesClassifier(n_estimators=n_trees, max_depth=params["max_depth"], min_samples_leaf=10,
                                    max_features="sqrt", class_weight=cw, n_jobs=1, random_state=seed)
    if name == "hist_gradient_boosting":
        return HistGradientBoostingClassifier(learning_rate=params["learning_rate"], max_leaf_nodes=params["max_leaf_nodes"],
                                              max_iter=n_trees * 2, class_weight=cw, random_state=seed)
    if name == "gradient_boosting":
        return GradientBoostingClassifier(n_estimators=n_trees, max_depth=params["max_depth"], subsample=0.5,
                                          random_state=seed)
    if name == "xgboost":
        from xgboost import XGBClassifier
        return XGBClassifier(n_estimators=n_trees * 2, max_depth=params["max_depth"], learning_rate=params["learning_rate"],
                             scale_pos_weight=pos_weight if strategy == "class_weight" else 1.0, n_jobs=1,
                             random_state=seed, eval_metric="logloss", tree_method="hist")
    if name == "lightgbm":
        from lightgbm import LGBMClassifier
        return LGBMClassifier(n_estimators=n_trees * 2, num_leaves=params["num_leaves"], learning_rate=params["learning_rate"],
                              class_weight=cw, n_jobs=1, random_state=seed, verbose=-1)
    raise KeyError(name)


def fit_candidate(name: str, params: dict, strategy: str, Xtr: pd.DataFrame, ytr: np.ndarray, cfg: dict,
                  specs: dict, seed: int) -> Pipeline:
    """imputer(+scaler) fitted on TRAIN -> resampling on TRAIN -> estimator. Returns a ready inference Pipeline."""
    spec, tcfg = specs[name], cfg["training"]
    rng = np.random.default_rng(seed)
    imputer = SimpleImputer(strategy="median").fit(Xtr)
    X = imputer.transform(Xtr)
    scaler = StandardScaler().fit(X) if spec["scale"] else None
    if scaler is not None:
        X = scaler.transform(X)
    X = X.astype(np.float32)
    y = np.asarray(ytr).astype(np.int8)
    cat_idx = [list(Xtr.columns).index("monsoon_flag")] if "monsoon_flag" in Xtr.columns else []
    if strategy == "random_oversample":
        X, y = random_oversample(X, y, tcfg["oversample_target_ratio"], rng)
    elif strategy == "smote":
        X, y = smote(X, y, tcfg["oversample_target_ratio"], tcfg["smote_k_neighbors"], rng, cat_idx)
    elif strategy != "class_weight":
        raise ValueError(f"unknown strategy {strategy}")
    pos_weight = float((y == 0).sum() / max(1, (y == 1).sum()))
    est = make_estimator(name, params, strategy, seed, spec["n_trees"], pos_weight)
    if name == "gradient_boosting":     # sklearn GB is slow: cap rows (keep every positive), weight classes
        keep = np.arange(len(y))
        if len(keep) > tcfg["gb_max_rows"]:
            pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
            n_neg = min(len(neg), max(0, tcfg["gb_max_rows"] - len(pos)))
            keep = np.sort(np.concatenate([pos, rng.choice(neg, n_neg, replace=False)]))
        yk = y[keep]
        w_pos = float((yk == 0).sum() / max(1, (yk == 1).sum())) if strategy == "class_weight" else 1.0
        est.fit(X[keep], yk, sample_weight=np.where(yk == 1, w_pos, 1.0))
    else:
        est.fit(X, y)
    steps = [("imputer", imputer)] + ([("scaler", scaler)] if scaler is not None else []) + [("model", est)]
    return Pipeline(steps)


def predict_scores(pipe: Pipeline, X: pd.DataFrame, chunk: int = 200_000) -> np.ndarray:
    out = np.empty(len(X), dtype=np.float32)
    for i in range(0, len(X), chunk):
        out[i:i + chunk] = pipe.predict_proba(X.iloc[i:i + chunk])[:, 1]
    return out


# ------------------------------------------------------------------------------------ orchestration
def _prepare_horizon(frame: pd.DataFrame, masks, label: str, features: list[str] | None, cfg: dict, seed: int):
    train_m, val_m, test_m = masks
    tr_stat = frame.loc[train_m, ["district_code", "monsoon_flag", "rain_sum7", label]]
    stats = DistrictStats().fit(tr_stat, label)
    ytr_full = frame.loc[train_m, label].to_numpy()
    keep = subsample_negatives(ytr_full, cfg["training"]["negatives_per_positive"], np.random.default_rng(seed))
    tr_idx = np.flatnonzero(train_m)[keep]
    train = stats.transform(frame.iloc[tr_idx])
    val = stats.transform(frame.loc[val_m])
    test = stats.transform(frame.loc[test_m])
    return stats, train, val, test


def run_training(cfg: dict, quick: bool = False, set_latest: bool = True) -> dict:
    t_start = time.time()
    seed = cfg["training"]["random_state"]
    processed = resolve_path(cfg, "processed_dir")
    frame = pd.read_pickle(processed / "model_frame.pkl")
    horizons = list(cfg["labels"]["horizons"])
    primary = cfg["labels"]["primary_horizon"]
    if quick:
        codes = np.sort(frame["district_code"].unique())
        pick = np.random.default_rng(seed).choice(codes, max(30, len(codes) // 8), replace=False)
        frame = frame[frame["district_code"].isin(pick)].reset_index(drop=True)
        log.warning("QUICK mode: %d districts only. Results are for smoke-testing, not for production.", len(pick))
    sp = cfg["split"]
    train_m, val_m, test_m, split_info = chronological_split(
        frame["date"], (sp["train"], sp["validation"], sp["test"]), sp["purge_days"])
    log.info("Split %s | rows train/val/test = %s/%s/%s", split_info, f"{train_m.sum():,}", f"{val_m.sum():,}", f"{test_m.sum():,}")
    masks = (train_m, val_m, test_m)
    specs = model_specs(seed, quick)

    out_dir = new_version_dir(resolve_path(cfg, "models_dir"))
    version = out_dir.name + ("_quick" if quick else "")
    results: dict = {}
    base_candidates = [c for c in feature_names(cfg)]
    cand = base_candidates + DistrictStats.COLUMNS

    # ---------------------------------------------------------------- primary horizon: comparison
    label = f"y{primary}"
    stats, train, val, test = _prepare_horizon(frame, masks, label, None, cfg, seed)
    ytr, yva, yte = train[label].to_numpy(), val[label].to_numpy(), test[label].to_numpy()
    log.info("Primary h=%d | train(sub) %s rows (%d pos) | val %s rows (%d pos) | test %s rows (%d pos)", primary,
             f"{len(train):,}", ytr.sum(), f"{len(val):,}", yva.sum(), f"{len(test):,}", yte.sum())
    fs = select_features(train, ytr, cand, cfg, seed)
    feats = fs["selected"]
    fs["table"].to_csv(out_dir / "feature_selection.csv")

    # ---- baselines
    baselines = []
    for bname, col in (("baseline_rain_sum3_rule", "rain_sum3"), ("baseline_district_flood_rate", "dist_flood_rate")):
        sv, st_ = np.nan_to_num(val[col].to_numpy()), np.nan_to_num(test[col].to_numpy())
        thr = select_threshold(yva, sv, cfg["training"]["threshold_method"], cfg["training"]["min_recall"])
        baselines.append({"model": bname, "val": classification_metrics(yva, sv, thr), "test": classification_metrics(yte, st_, thr)})
    z = np.zeros(len(yva)), np.zeros(len(yte))
    baselines.append({"model": "baseline_always_no_flood", "val": classification_metrics(yva, z[0], 0.5),
                      "test": classification_metrics(yte, z[1], 0.5)})

    # ---- resampling strategy comparison on two fast, representative models (validation only)
    strat_rows = []
    for strategy in cfg["training"]["resampling_candidates"]:
        for name in [n for n in ("logistic_regression", "hist_gradient_boosting") if n in specs]:
            t0 = time.time()
            pipe = fit_candidate(name, specs[name]["grid"][0], strategy, train[feats], ytr, cfg, specs, seed)
            s = predict_scores(pipe, val[feats])
            strat_rows.append({"strategy": strategy, "model": name, "val_roc_auc": classification_metrics(yva, s, 0.5)["roc_auc"],
                               "val_best_f1": best_f1(yva, s), "seconds": round(time.time() - t0, 1)})
            log.info("strategy %-18s %-24s auc=%.3f f1=%.3f", strategy, name, strat_rows[-1]["val_roc_auc"], strat_rows[-1]["val_best_f1"])
    strat_df = pd.DataFrame(strat_rows)
    strat_df.to_csv(out_dir / "strategy_comparison.csv", index=False)
    strategy = strat_df.groupby("strategy")["val_best_f1"].mean().idxmax()
    log.info("Selected imbalance strategy (by mean validation F1): %s", strategy)

    # ---- tune + compare all models with the chosen strategy
    comp, fitted = [], {}
    for name, spec in specs.items():
        best = None
        for params in spec["grid"]:
            t0 = time.time()
            try:
                pipe = fit_candidate(name, params, strategy, train[feats], ytr, cfg, specs, seed)
                secs = time.time() - t0
                s = predict_scores(pipe, val[feats])
            except Exception as exc:  # noqa: BLE001 - one failing model must not stop the run
                log.exception("Model %s %s failed: %s", name, params, exc)
                continue
            f1 = best_f1(yva, s)
            log.info("%-24s %-40s val_f1=%.3f auc=%.3f (%.0fs)", name, params, f1, classification_metrics(yva, s, 0.5)["roc_auc"], secs)
            if best is None or f1 > best["f1"]:
                best = dict(f1=f1, params=params, pipe=pipe, val_scores=s, seconds=secs)
        if best is None:
            continue
        thr = select_threshold(yva, best["val_scores"], cfg["training"]["threshold_method"], cfg["training"]["min_recall"])
        ts = predict_scores(best["pipe"], test[feats])
        comp.append({"model": name, "strategy": strategy, "params": best["params"], "train_seconds": round(best["seconds"], 1),
                     "val": classification_metrics(yva, best["val_scores"], thr), "test": classification_metrics(yte, ts, thr),
                     "val_f1_selection": best["f1"]})
        fitted[name] = best
    if not comp:
        raise RuntimeError("No model could be trained")
    winner = max(comp, key=lambda r: (r["val_f1_selection"], r["val"]["roc_auc"]))["model"]
    log.info("Best model on validation: %s", winner)

    flat = []
    for r in comp:
        flat.append({"model": r["model"], "selected": r["model"] == winner, "strategy": r["strategy"], "params": str(r["params"]),
                     "train_seconds": r["train_seconds"], "threshold": r["val"]["threshold"],
                     **{f"val_{k}": r["val"][k] for k in ("roc_auc", "accuracy", "precision", "recall")},
                     **{f"test_{k}": r["test"][k] for k in ("roc_auc", "accuracy", "precision", "recall")}})
    pd.DataFrame(flat).to_csv(out_dir / "model_comparison.csv", index=False)
    for b in baselines:
        flat_b = {"model": b["model"], **{f"val_{k}": b["val"][k] for k in ("roc_auc", "accuracy", "precision", "recall")},
                  **{f"test_{k}": b["test"][k] for k in ("roc_auc", "accuracy", "precision", "recall")}}
        flat.append(flat_b)
    pd.DataFrame(flat).to_csv(out_dir / "model_comparison_with_baselines.csv", index=False)

    # ---------------------------------------------------------------- per-horizon production models
    win = next(r for r in comp if r["model"] == winner)
    rc = cfg["risk_categories"]
    win_pipe = fitted[winner]["pipe"]
    fitted.clear()                       # free large non-winning ensembles (3 GB RAM safety)
    gc.collect()
    for h in sorted(horizons, key=lambda x: x != primary):
        lab = f"y{h}"
        if h == primary:
            h_stats, h_train, h_val, h_test, pipe = stats, train, val, test, win_pipe
        else:
            h_stats = h_train = h_val = h_test = None
            gc.collect()
            h_stats, h_train, h_val, h_test = _prepare_horizon(frame, masks, lab, None, cfg, seed)
            pipe = fit_candidate(winner, win["params"], strategy, h_train[feats], h_train[lab].to_numpy(), cfg, specs, seed)
        sv, st_ = predict_scores(pipe, h_val[feats]), predict_scores(pipe, h_test[feats])
        yv, yt = h_val[lab].to_numpy(), h_test[lab].to_numpy()
        thr = select_threshold(yv, sv, cfg["training"]["threshold_method"], cfg["training"]["min_recall"])
        hd = out_dir / f"h{h}"
        hd.mkdir(exist_ok=True)
        joblib.dump(pipe, hd / "model.joblib")
        joblib.dump(h_stats, hd / "district_stats.joblib")
        meta = {
            "model_version": version, "trained_at": datetime.now().isoformat(timespec="seconds"), "horizon_days": h,
            "model_name": winner, "params": win["params"], "imbalance_strategy": strategy, "features": feats,
            "decision_threshold": thr, "threshold_method": cfg["training"]["threshold_method"],
            "risk_cutoffs": {"moderate": float(np.quantile(sv, rc["moderate_quantile"])),
                             "high": float(np.quantile(sv, rc["high_quantile"])),
                             "very_high": float(np.quantile(sv, rc["very_high_quantile"]))},
            "risk_quantiles": {k: rc[f"{k}_quantile"] for k in ("moderate", "high", "very_high")},
            "validation_metrics": classification_metrics(yv, sv, thr), "test_metrics": classification_metrics(yt, st_, thr),
            "split": split_info, "label_definition": f"recorded flood-episode onset within the next {h} day(s)",
            "calibration_note": CALIBRATION_NOTE, "quick_mode": quick,
            "environment": {"python": platform.python_version(), "sklearn": sklearn.__version__},
        }
        save_json(meta, hd / "meta.json")
        results[h] = meta
        if h == primary:
            del train, val, test, h_train, h_val, h_test
        gc.collect()
        log.info("h=%d saved | val %s | test %s", h, {k: round(v, 3) for k, v in meta["validation_metrics"].items() if isinstance(v, float)},
                 {k: round(v, 3) for k, v in meta["test_metrics"].items() if isinstance(v, float)})

    save_json({"version": version, "winner": winner, "strategy": strategy, "split": split_info, "models": comp,
               "baselines": baselines, "feature_selection_dropped": fs["dropped"], "config": cfg,
               "total_seconds": round(time.time() - t_start, 1)}, out_dir / "training_report.json")
    (out_dir / "READY").write_text(version)
    if set_latest and not quick:
        (out_dir.parent / "LATEST").write_text(out_dir.name)
    log.info("Training finished in %.1f min -> %s", (time.time() - t_start) / 60, out_dir)
    return {"dir": str(out_dir), "winner": winner, "strategy": strategy}
