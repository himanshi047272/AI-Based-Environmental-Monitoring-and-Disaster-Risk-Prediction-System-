"""Shared helpers: config, paths, name normalisation, versioned artifact directories."""
from __future__ import annotations

import json
import logging
import os
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]


def load_config(path: str | os.PathLike | None = None) -> dict:
    p = Path(path or os.environ.get("ECOSHIELD_CONFIG") or ROOT / "config" / "settings.yaml")
    if not p.is_absolute():
        p = ROOT / p
    with open(p, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def resolve_path(cfg: dict, key: str, *parts: str, create: bool = False) -> Path:
    raw = Path(cfg["paths"][key])
    p = raw if raw.is_absolute() else ROOT / raw
    p = p.joinpath(*parts)
    if create:
        (p if not p.suffix else p.parent).mkdir(parents=True, exist_ok=True)
    return p


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    logging.basicConfig(level=level, format="%(asctime)s | %(levelname)s | %(message)s", datefmt="%H:%M:%S")
    return logging.getLogger("ecoshield")


def normalize_name(value: Any) -> str:
    """Lower-case, accent-free, punctuation-free name used ONLY as a documented fallback join key."""
    if value is None:
        return ""
    s = str(value)
    if s.lower() in {"nan", "none", ""}:
        return ""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii").lower()
    s = s.replace("&", " and ")
    s = re.sub(r"\(.*?\)", " ", s)
    s = re.sub(r"\bdistrict\b", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def to_snake(name: str) -> str:
    return re.sub(r"[^0-9a-z]+", "_", str(name).strip().lower()).strip("_")


def save_json(obj: Any, path: os.PathLike) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, default=_json_default)


def _json_default(o: Any):
    try:
        import numpy as np
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return None if o != o else float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:  # pragma: no cover
        pass
    if hasattr(o, "isoformat"):
        return o.isoformat()
    return str(o)


def load_json(path: os.PathLike) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def new_version_dir(models_dir: Path) -> Path:
    """Create a fresh, timestamped model directory. Never reuses or overwrites an existing one."""
    models_dir.mkdir(parents=True, exist_ok=True)
    base = datetime.now().strftime("v%Y%m%d_%H%M%S")
    d, n = models_dir / base, 1
    while d.exists():
        d = models_dir / f"{base}_{n}"
        n += 1
    d.mkdir()
    return d


def latest_version_dir(models_dir: Path) -> Path | None:
    """Return the model dir named in models/LATEST (written only after a training run completes)."""
    pointer = models_dir / "LATEST"
    if pointer.exists():
        d = models_dir / pointer.read_text().strip()
        if d.is_dir():
            return d
    return None


def skip_test(reason: str):
    import unittest
    raise unittest.SkipTest(reason)


def require_module(name: str):
    import importlib
    try:
        return importlib.import_module(name)
    except ImportError:
        skip_test(f"{name} not installed")
