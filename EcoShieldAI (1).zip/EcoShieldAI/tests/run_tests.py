"""Minimal runner so tests work without pytest:  python -m tests.run_tests   (pytest also works)."""
import importlib
import pkgutil
import sys
import traceback
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> int:
    passed = failed = skipped = 0
    for m in sorted(pkgutil.iter_modules([str(Path(__file__).parent)]), key=lambda m: m.name):
        if not m.name.startswith("test_"):
            continue
        mod = importlib.import_module(f"tests.{m.name}")
        for name in sorted(n for n in dir(mod) if n.startswith("test_")):
            try:
                getattr(mod, name)()
                passed += 1
                print(f"PASS  {m.name}::{name}")
            except unittest.SkipTest as e:
                skipped += 1
                print(f"SKIP  {m.name}::{name}  ({e})")
            except Exception:
                failed += 1
                print(f"FAIL  {m.name}::{name}")
                traceback.print_exc()
    print(f"\n{passed} passed, {failed} failed, {skipped} skipped")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
