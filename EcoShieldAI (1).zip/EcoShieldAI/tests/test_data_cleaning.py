import numpy as np
import pandas as pd

from src import data_cleaning as dc
from src.data_loader import parse_dates_best
from tests.helpers import cfg, rain_rows


def test_date_parsing_picks_best_format_and_counts_invalid():
    s = pd.Series(["02-07-1967 00:00", "22-07-1967 00:00", "garbage", None])
    parsed, fmt, invalid = parse_dates_best(s, dc.FLOOD_DATE_FORMATS)
    assert fmt == "%d-%m-%Y %H:%M" and invalid == 1 and parsed.iloc[0] == pd.Timestamp("1967-07-02")


def test_invalid_rainfall_becomes_nan_not_zero():
    df = rain_rows(days=10)
    df.loc[0, "actual"] = -5.0
    df.loc[1, "actual"] = 99999.0
    df.loc[2, "actual"] = np.nan
    clean, rep = dc.clean_rainfall(df, cfg())
    assert rep["invalid_rainfall_values_set_nan"] == 2
    assert clean["actual"].isna().sum() == 3 and (clean["actual"] == 0).sum() == 0


def test_identical_duplicates_collapse_conflicting_code_is_ambiguous():
    df = rain_rows(codes=(1, 2), days=30)
    df = pd.concat([df, df[df.district_code == 1].head(5)])                    # exact duplicates
    amb = rain_rows(codes=(3,), days=30)
    amb2 = amb.copy(); amb2["actual"] += 1.0                                     # two entities sharing code 3
    clean, rep = dc.clean_rainfall(pd.concat([df, amb, amb2]), cfg())
    assert 3 in rep["ambiguous_district_codes"] and 3 not in set(clean.district_code)
    assert not clean.duplicated(["district_code", "date"]).any()
    assert rep["duplicate_rows_removed"] == 5


def test_insufficient_history_flagged():
    c = cfg(); c["data"]["min_history_days"] = 30
    df = pd.concat([rain_rows(codes=(1,), days=40), rain_rows(codes=(2,), days=10)])
    _, rep = dc.clean_rainfall(df, c)
    assert rep["insufficient_history_districts"] == [2]


def test_code_list_parsing_counts_bad_tokens():
    assert dc.parse_code_list("348, None, 352,") == ([348, 352], 1)
    assert dc.parse_code_list(None) == ([], 0)


def test_flood_cleaning_rejects_bad_start_fixes_end_and_dedups():
    df = pd.DataFrame({"uei": ["a", "b", "c", "c2"], "start_date": ["01-07-2020 00:00", None, "05-07-2020 00:00", "01-07-2020 00:00"],
                       "end_date": ["03-07-2020 00:00", None, "01-07-2020 00:00", "03-07-2020 00:00"],
                       "duration_days": ["3", None, "4", "3"], "state": ["X"] * 4, "districts": ["A"] * 4,
                       "district_lgd_codes": ["1"] * 4, "state_codes": ["9"] * 4})
    ev, rep, rej = dc.clean_floods(df)
    assert len(rej) == 1 and rep["exact_duplicate_events_removed"] == 1
    fixed = ev[ev.uei == "c"].iloc[0]
    assert fixed["end_date"] == pd.Timestamp("2020-07-08") and fixed["end_adjusted"]
