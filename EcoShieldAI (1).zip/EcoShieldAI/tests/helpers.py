import numpy as np
import pandas as pd

from src.utils import load_config


def cfg():
    c = load_config()
    c["data"]["min_history_days"] = 5
    return c


def rain_rows(codes=(1, 2), days=40, start="2020-01-01", seed=0, gaps=()):
    rng = np.random.default_rng(seed)
    rows = []
    for c in codes:
        for i, d in enumerate(pd.date_range(start, periods=days)):
            if (c, i) in gaps:
                continue
            rows.append(dict(date=d.strftime("%Y-%m-%d"), state_code=9, state_name="State", district_code=c,
                             district_name=f"D{c}", actual=float(rng.gamma(0.5, 6)), rfs=0.1, normal=1.0, deviation=0.0))
    return pd.DataFrame(rows)
