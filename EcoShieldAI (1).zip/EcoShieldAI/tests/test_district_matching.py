import pandas as pd

from src import data_cleaning as dc
from src import district_matching as dm
from src.utils import normalize_name


def _master():
    return pd.DataFrame({"district_code": [1, 2, 3, 4], "district_name": ["Patna", "Gaya", "Nagpur", "Patna"],
                         "state_code": [10, 10, 27, 9], "state_name": ["Bihar", "Bihar", "Maharashtra", "UP"],
                         "district_norm": ["patna", "gaya", "nagpur", "patna"], "state_norm": ["bihar", "bihar", "maharashtra", "up"]})


def _events(rows):
    df = pd.DataFrame(rows, columns=["uei", "start_date", "end_date", "state", "districts", "district_lgd_codes", "state_codes"])
    df["duration_days"] = "1"
    for c in ("start_date", "end_date"):
        df[c] = pd.to_datetime(df[c])
    ev, _, _ = dc.clean_floods(df.astype({"start_date": str, "end_date": str}).assign(
        start_date=lambda d: pd.to_datetime(d.start_date).dt.strftime("%d-%m-%Y %H:%M"),
        end_date=lambda d: pd.to_datetime(d.end_date).dt.strftime("%d-%m-%Y %H:%M")))
    return ev


def test_code_match_state_check_invalid_and_ambiguous():
    ev = _events([("e1", "2020-07-01", "2020-07-02", "Bihar", "Patna, Gaya, X", "1, 2, 999, 3, 7", "10"),
                  ("e2", "2020-07-03", "2020-07-04", "Bihar", "", "7", "10")])
    matched, rep, det = dm.match_events(ev, _master(), ambiguous_codes=[7])
    assert set(matched.district_code) == {1, 2}                      # 3 is Maharashtra -> state mismatch
    st = det.set_index("token")["status"].to_dict()
    assert st["999"] == "invalid_code" and st["3"] == "state_mismatch" and st["7"] == "ambiguous_code"
    assert rep["events_unmatched"] == 1 and (matched.match_source == "lgd_code").all()


def test_name_fallback_only_when_unique_within_state():
    ev = _events([("e1", "2020-07-01", "2020-07-02", "Bihar", "Patna", "", "10"),
                  ("e2", "2020-07-01", "2020-07-02", "X", "Patna", "", "10,9"),      # Patna exists in two states -> ambiguous
                  ("e3", "2020-07-01", "2020-07-02", "Bihar", "Unknownpur", "", "10")])
    matched, rep, det = dm.match_events(ev, _master())
    assert matched[["district_code", "match_source"]].values.tolist() == [[1, "name_fallback"]]
    assert set(det.status) >= {"matched_name_fallback", "ambiguous_name", "unmatched_name"}


def test_normalize_name():
    assert normalize_name("Kaimur (Bhabua)") == "kaimur" and normalize_name("Pashchim  Champaran District") == "pashchim champaran"
    assert normalize_name(None) == ""
