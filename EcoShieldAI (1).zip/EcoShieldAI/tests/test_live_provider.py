import json
import tempfile
from pathlib import Path

from src.live_data_provider import OpenMeteoProvider, get_api_key
from tests.helpers import cfg


class Resp:
    def __init__(self, code=200, payload=None, headers=None):
        self.status_code, self._p, self.headers = code, payload, headers or {}
    def json(self): return self._p


class Session:
    def __init__(self, seq): self.seq, self.calls = list(seq), []
    def get(self, url, params=None, timeout=None):
        self.calls.append((url, params, timeout))
        r = self.seq.pop(0) if len(self.seq) > 1 else self.seq[0]
        if isinstance(r, Exception):
            raise r
        return r


def _payload(n, unit="mm", days=("2099-01-01", "2099-01-02")):
    one = {"daily": {"time": list(days), "precipitation_sum": [1.0, None]}, "daily_units": {"precipitation_sum": unit}}
    return one if n == 1 else [one] * n


def _prov(session, cent=None, **live):
    c = cfg()["live"]; c.update(live)
    return OpenMeteoProvider(c, cent or {1: (20.0, 70.0)}, Path(tempfile.mkdtemp()), api_key="k", session=session, sleep=lambda s: None)


def test_success_records_source_timestamps_and_marks_future_days_as_forecast():
    s = Session([Resp(200, _payload(1, days=("2000-01-01", "2099-01-01")))])
    res = _prov(s).fetch(force=True)
    assert res.status == "ok" and res.usable and res.source == "open-meteo" and res.retrieved_at is not None
    assert set(res.data.kind) == {"observed", "forecast"} and res.latest_observation_date == "2000-01-01"
    assert s.calls[0][2] == cfg()["live"]["timeout_s"] and s.calls[0][1]["apikey"] == "k"


def test_unit_mismatch_rejected():
    res = _prov(Session([Resp(200, _payload(1, unit="inch"))])).fetch(force=True)
    assert res.status == "error" and "unit" in res.message and res.data is None


def test_rate_limit_retries_then_friendly_error():
    s = Session([Resp(429, headers={"Retry-After": "1"})])
    res = _prov(s, retries=3).fetch(force=True)
    assert res.status == "error" and "rate" in res.message.lower() and len(s.calls) == 3


def test_timeout_gives_error_not_exception():
    res = _prov(Session([TimeoutError("boom")])).fetch(force=True)
    assert res.status == "error" and "network" in res.message.lower()


def test_falls_back_to_stale_cache_when_provider_fails():
    p = _prov(Session([Resp(200, _payload(1))]))
    assert p.fetch(force=True).status == "ok"
    p.session = Session([Resp(500)])
    res = p.fetch(force=True)
    assert res.status == "stale" and res.data is not None and "cached" in res.message


def test_cache_served_within_ttl_without_network():
    p = _prov(Session([Resp(200, _payload(1))]), cache_ttl_minutes=60)
    p.fetch(force=True)
    p.session = Session([TimeoutError()])
    assert p.fetch().status == "cached" and len(p.session.calls) == 0


def test_no_centroids_is_error_and_batches_respect_size():
    assert _prov(Session([Resp()]), cent={}).fetch(force=True).status == "error"
    s = Session([Resp(200, _payload(2))])
    _prov(s, cent={1: (1, 1), 2: (2, 2), 3: (3, 3)}, batch_size=2)
    cent = {1: (1, 1), 2: (2, 2), 3: (3, 3)}
    s = Session([Resp(200, _payload(2)), Resp(200, _payload(1))])
    res = _prov(s, cent=cent, batch_size=2).fetch(force=True)
    assert len(s.calls) == 2 and res.data.district_code.nunique() == 3


def test_api_key_from_environment_only_and_none_hardcoded_in_source():
    import os
    c = cfg()
    os.environ.pop(c["live"]["api_key_env"], None)
    assert get_api_key(c, {}) is None
    os.environ[c["live"]["api_key_env"]] = "secret"
    assert get_api_key(c) == "secret"
    os.environ.pop(c["live"]["api_key_env"])
    src = (Path(__file__).resolve().parents[1] / "src" / "live_data_provider.py").read_text()
    assert "apikey=" not in src and "api_key =" not in src.replace("self.api_key = api_key", "")
