import numpy as np
import pandas as pd

from src import feature_engineering as fe
from src.train_models import fit_candidate, model_specs, random_oversample, smote, subsample_negatives
from tests.helpers import cfg, rain_rows


def _cube(gaps=(), days=60):
    df = rain_rows(codes=(1, 2), days=days, gaps=gaps)
    df["date"] = pd.to_datetime(df["date"])
    return fe.build_rain_cube(df)


def test_lag_is_calendar_day_not_previous_row():
    cube = _cube(gaps={(1, 19)})                             # district 1 is missing day index 19
    feats = fe.compute_features(cube["actual"], cube["normal"], cube["dates"], cube["codes"], cfg())
    r = feats[(feats.district_code == 1)].reset_index(drop=True)
    assert np.isnan(cube["actual"][19, 0])
    assert np.isnan(r.loc[20, "rain_lag1"])                  # yesterday is missing -> NaN, not day 18 (previous row)
    assert np.isclose(r.loc[21, "rain_lag1"], cube["actual"][20, 0])
    assert np.isclose(r.loc[30, "rain_lag7"], cube["actual"][23, 0])


def test_features_do_not_use_future_data():
    cube = _cube()
    a = cube["actual"].copy()
    f1 = fe.compute_features(a, cube["normal"], cube["dates"], cube["codes"], cfg())
    a2 = a.copy(); a2[40:] = 999.0                           # alter everything after day 39
    f2 = fe.compute_features(a2, cube["normal"], cube["dates"], cube["codes"], cfg())
    early = f1.date < cube["dates"][40]
    cols = [c for c in f1.columns if c not in ("date", "district_code") and not c.startswith("state_")]
    pd.testing.assert_frame_equal(f1.loc[early, cols].reset_index(drop=True), f2.loc[early, cols].reset_index(drop=True))


def test_missing_rainfall_never_zero_filled_and_window_rule():
    cube = _cube()
    cube["actual"][10:20, 0] = np.nan
    f = fe.compute_features(cube["actual"], cube["normal"], cube["dates"], cube["codes"], cfg())
    r = f[f.district_code == 1].reset_index(drop=True)
    assert np.isnan(r.loc[15, "rain_0"]) and np.isnan(r.loc[15, "rain_sum3"])


def test_transformations_reproducible():
    cube = _cube()
    a = fe.compute_features(cube["actual"], cube["normal"], cube["dates"], cube["codes"], cfg())
    b = fe.compute_features(cube["actual"], cube["normal"], cube["dates"], cube["codes"], cfg())
    pd.testing.assert_frame_equal(a, b)
    assert set(fe.feature_names(cfg())) <= set(a.columns)


def test_district_stats_use_training_rows_only():
    rng = np.random.default_rng(0)
    tr = pd.DataFrame({"district_code": [1] * 50 + [2] * 50, "monsoon_flag": 1.0, "rain_sum7": rng.random(100) * 50,
                       "y3": rng.integers(0, 2, 100)})
    s1 = fe.DistrictStats().fit(tr, "y3")
    val = tr.copy(); val["y3"] = 1; val["rain_sum7"] = 1e6                 # later (validation) data must not matter
    s2 = fe.DistrictStats().fit(tr, "y3")
    assert s1.flood_rate_.equals(s2.flood_rate_) and s1.p95_.equals(s2.p95_)
    out = s1.transform(pd.DataFrame({"district_code": [1, 99], "rain_sum7": [10.0, 10.0], "rain_sum3": [5.0, 5.0], "monsoon_flag": [1.0, 1.0]}))
    assert np.isnan(out.loc[1, "dist_flood_rate"])                       # unseen district stays NaN (imputed later)


def test_leakage_names_detected():
    assert fe.leakage_prone(["rain_0", "y3", "y3_label", "future_rain", "onset_flag"]) == ["y3", "y3_label", "future_rain", "onset_flag"]
    assert fe.leakage_prone(["doy_sin", "doy_cos", "monsoon_flag", "rain_lag1"]) == []     # regression: 'doy_' must not match 'y_' 


def test_smote_and_oversampling_only_add_minority_rows_and_keep_originals():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(500, 4)).astype("float32"); X[:, 3] = X[:, 3] > 0
    y = np.zeros(500, "int8"); y[:15] = 1
    Xs, ys = smote(X, y, 0.25, 5, rng, [3])
    assert len(Xs) > len(X) and (ys[len(y):] == 1).all() and np.array_equal(Xs[:len(X)], X)
    assert set(np.unique(Xs[:, 3])) <= {0.0, 1.0}                       # categorical column never interpolated
    Xo, yo = random_oversample(X, y, 0.25, rng)
    assert (yo[len(y):] == 1).all() and (yo == 0).sum() == (y == 0).sum()


def test_resampling_applied_to_training_data_only_and_inputs_not_mutated():
    rng = np.random.default_rng(1)
    cols = ["a", "b", "monsoon_flag"]
    Xtr = pd.DataFrame(rng.normal(size=(400, 3)), columns=cols); Xtr["monsoon_flag"] = (Xtr.monsoon_flag > 0) * 1.0
    ytr = (rng.random(400) < 0.05).astype(int)
    Xva = Xtr.sample(100, random_state=0).copy(); before = Xva.copy(); ntr = len(Xtr)
    c = cfg(); specs = model_specs(0, quick=True)
    pipe = fit_candidate("logistic_regression", {"C": 1.0}, "smote", Xtr, ytr, c, specs, 0)
    assert len(Xtr) == ntr and Xva.equals(before)
    assert pipe.predict_proba(Xva)[:, 1].shape == (100,)


def test_negative_subsampling_keeps_all_positives():
    y = np.array([1] * 5 + [0] * 500)
    keep = subsample_negatives(y, 10, np.random.default_rng(0))
    assert y[keep].sum() == 5 and len(keep) == 55
