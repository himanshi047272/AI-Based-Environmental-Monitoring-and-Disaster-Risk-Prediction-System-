import csv
import io
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from src import flood_risk_prediction as fp
from src.evaluate_models import classification_metrics, select_threshold
from src.utils import latest_version_dir, new_version_dir, require_module
from tests.helpers import cfg


def test_validate_feature_frame_fails_loudly_on_missing_columns():
    df = pd.DataFrame({"rain_0": [1.0]})
    try:
        fp.validate_feature_frame(df, ["rain_0", "rain_sum3"])
        raise AssertionError("should have raised")
    except ValueError as e:
        assert "rain_sum3" in str(e)
    assert list(fp.validate_feature_frame(pd.DataFrame({"b": [1], "a": [2]}), ["a", "b"]).columns) == ["a", "b"]


def test_risk_categories_and_missing_prediction_is_unavailable_not_low():
    cut = {"moderate": 0.2, "high": 0.5, "very_high": 0.8}
    cat = fp.assign_risk_category([0.05, 0.3, 0.6, 0.9, np.nan], cut)
    assert list(cat) == ["Low", "Moderate", "High", "Very high", "Unavailable"]


def test_classification_metrics_confusion_matrix_and_threshold_on_validation():
    y = np.array([0, 0, 0, 1, 1, 0]); s = np.array([.1, .2, .6, .7, .9, .3])
    thr = select_threshold(y, s, "f1")
    m = classification_metrics(y, s, thr)
    assert set(m["confusion_matrix"]) == {"tn", "fp", "fn", "tp"} and sum(m["confusion_matrix"].values()) == 6
    assert 0 <= m["roc_auc"] <= 1 and "rmse" not in m                    # no regression metrics for binary labels


def test_missing_model_gives_clear_error_and_versions_never_overwrite():
    with tempfile.TemporaryDirectory() as d:
        c = cfg(); c["paths"]["models_dir"] = d
        try:
            fp.load_production_model(c, 3)
            raise AssertionError
        except fp.ModelNotFoundError as e:
            assert "pipeline train" in str(e)
        a, b = new_version_dir(Path(d)), new_version_dir(Path(d))
        assert a != b and a.exists() and b.exists() and latest_version_dir(Path(d)) is None


def test_csv_export_roundtrip_keeps_unavailable_rows():
    df = pd.DataFrame({"district_code": [1, 2], "risk_score": [0.4, np.nan], "risk_category": ["High", "Unavailable"]})
    back = pd.read_csv(io.StringIO(df.to_csv(index=False)))
    assert back.risk_category.tolist() == ["High", "Unavailable"] and back.risk_score.isna().sum() == 1


def test_latest_feasible_index():
    a = np.full((10, 4), np.nan); a[:6, :] = 1.0; a[6, :2] = 1.0
    assert fp.latest_feasible_index(a, 0.5) == 6 and fp.latest_feasible_index(a, 0.75) == 5


def test_dashboard_startup_does_not_retrain():
    """Runs app.py headlessly (needs streamlit + generated predictions). Verifies no training module is touched."""
    require_module("streamlit")
    from streamlit.testing.v1 import AppTest
    root = Path(__file__).resolve().parents[1]
    if not (root / "outputs/predictions/snapshot_predictions.csv").exists():
        from src.utils import skip_test
        skip_test("run the pipeline first")
    before = sorted(p.name for p in (root / "models").iterdir())
    at = AppTest.from_file(str(root / "app.py"), default_timeout=120).run()
    assert not at.exception, at.exception
    assert "src.train_models" not in sys.modules and sorted(p.name for p in (root / "models").iterdir()) == before
