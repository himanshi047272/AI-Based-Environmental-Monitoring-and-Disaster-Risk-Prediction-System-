import numpy as np
import pandas as pd

from src import label_generation as lg
from src.train_models import chronological_split


def _matched(rows):
    df = pd.DataFrame(rows, columns=["district_code", "start_date", "end_date"])
    df["start_date"] = pd.to_datetime(df.start_date); df["end_date"] = pd.to_datetime(df.end_date)
    return df


def test_overlapping_and_adjacent_events_merge_into_one_episode():
    m = _matched([(1, "2020-07-01", "2020-07-05"), (1, "2020-07-03", "2020-07-08"), (1, "2020-07-09", "2020-07-10"),
                  (1, "2020-08-01", "2020-08-02"), (2, "2020-07-01", "2020-07-01")])
    ep = lg.merge_episodes(m, 30)
    d1 = ep[ep.district_code == 1]
    assert len(d1) == 2 and d1.iloc[0].n_events_merged == 3 and d1.iloc[0].end == pd.Timestamp("2020-07-10")


def test_active_window_capped():
    ep = lg.merge_episodes(_matched([(1, "2020-01-01", "2020-12-31")]), 30)
    assert (ep.active_end.iloc[0] - ep.onset.iloc[0]).days == 29


def test_horizon_label_is_strictly_future_t_plus_1_to_h():
    dates = pd.date_range("2020-07-01", periods=12)
    ep = lg.merge_episodes(_matched([(1, "2020-07-08", "2020-07-09")]), 30)
    onset, active = lg.build_event_matrices(ep, dates, np.array([1]))
    y3 = lg.horizon_labels(onset, 3)[:, 0]
    pos_days = [str(d.date()) for d in dates[y3]]
    assert pos_days == ["2020-07-05", "2020-07-06", "2020-07-07"]          # onset day itself (07-08) is NOT its own label
    assert lg.horizon_labels(onset, 1)[:, 0].nonzero()[0].tolist() == [6]
    assert active[7:9, 0].all() and not active[6, 0]


def test_unknown_label_tail_masked():
    dates = pd.date_range("2020-07-01", periods=10)
    known = lg.label_known_mask(dates, 3, pd.Timestamp("2020-07-08"))
    assert known.tolist() == [True] * 5 + [False] * 5


def test_positive_rate_tables_by_year_month_state_district():
    dates = pd.date_range("2020-12-30", periods=5)
    y = np.zeros((5, 2), bool); y[0, 0] = True
    valid = np.ones((5, 2), bool)
    master = pd.DataFrame({"district_code": [1, 2], "district_name": ["a", "b"], "state_code": [9, 9], "state_name": ["S", "S"]})
    t = lg.positive_rate_tables(y, valid, dates, np.array([1, 2]), master)
    assert set(t) == {"year", "month", "state", "district"} and t["year"].positives.sum() == 1 and t["state"].valid_rows.iloc[0] == 10


def test_chronological_split_order_gap_and_no_overlap():
    dates = pd.Series(np.repeat(pd.date_range("2015-01-01", periods=1000), 3))
    tr, va, te, info = chronological_split(dates, (0.7, 0.15, 0.15), purge_days=3)
    assert not (tr & va).any() and not (va & te).any() and not (tr & te).any()
    assert dates[tr].max() < dates[va].min() < dates[va].max() < dates[te].min()
    assert (dates[va].min() - dates[tr].max()).days > 3 and abs(tr.mean() - 0.7) < 0.02
