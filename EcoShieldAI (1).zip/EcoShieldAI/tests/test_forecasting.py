import numpy as np
import pandas as pd

from src import rainfall_forecasting as rf
from src.evaluate_models import regression_metrics
from src.utils import require_module
from tests.helpers import cfg


class _StubResult:
    """AR(1)-like stand-in for a statsmodels result (tests orchestration without statsmodels)."""
    def __init__(self, y): self.y = np.asarray(y, float)
    def forecast(self, steps):
        last = self.y[np.isfinite(self.y)][-1]
        return np.full(steps, last * 0.8 + 0.2)
    def apply(self, y, refit=False): return _StubResult(y)


def stub_fitter(endog, order, seasonal, sqrt):
    return rf.Fitted(_StubResult(np.sqrt(endog) if sqrt else endog), order, seasonal, sqrt, {"aic": 1.0})


def failing_fitter(endog, order, seasonal, sqrt):
    raise np.linalg.LinAlgError("singular")


def _fc():
    c = cfg()["forecast"]
    c.update(min_history_days=100, fit_window_days=200, validation_origin_start="2020-09-01", validation_origin_end="2020-09-30",
             test_origin_start="2020-10-01", test_origin_end="2020-10-25")
    return c


def _series(n=330, seed=0):
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2020-01-01", periods=n)
    return np.where(rng.random(n) < 0.4, rng.gamma(1.5, 8, n), 0.0), dates


def test_acf_and_seasonal_period_selection():
    x = np.tile([0, 0, 0, 0, 0, 0, 10.0], 60)
    assert rf.acf_at_lag(x, 7) > 0.9 and rf.choose_seasonal_period(x, [7], 2.0) == 7
    noise = np.random.default_rng(0).normal(size=400)
    assert rf.choose_seasonal_period(noise, [7], 2.0) is None
    assert np.isnan(rf.acf_at_lag(np.ones(50), 7))


def test_insufficient_history_reported_unavailable_not_fabricated():
    s, d = _series(60)
    out = rf.forecast_district(s, d, _fc(), 59, stub_fitter)
    assert out["status"] == "unavailable" and "insufficient" in out["reason"] and "forecast" not in out


def test_mostly_missing_series_unavailable():
    s, d = _series()
    s[:200] = np.nan
    out = rf.forecast_district(s, d, _fc(), len(s) - 1, stub_fitter)
    assert out["status"] == "unavailable"


def test_convergence_failure_handled_gracefully():
    s, d = _series()
    out = rf.forecast_district(s, d, _fc(), len(s) - 1, failing_fitter)
    assert out["status"] == "unavailable" and "converge" in out["reason"]


def test_forecast_workflow_with_gaps_returns_nonnegative_3_day_values_and_baselines():
    s, d = _series()
    s[50:55] = np.nan                                        # gaps remain NaN
    out = rf.forecast_district(s, d, _fc(), len(s) - 1, stub_fitter)
    assert out["status"] == "ok" and len(out["forecast"]) == 3 and min(out["forecast"]) >= 0
    t = out["test"]
    assert t["model"].shape == t["truth"].shape == t["persistence"].shape and t["truth"].shape[1] == 3
    pooled = rf.pooled_metrics({1: out}, 3)
    assert set(pooled) == {"model", "persistence", "mean_last7"} and set(pooled["model"]["h1"]) == {"rmse", "mse", "r2", "n"}


def test_regression_metrics_r2_can_be_negative_and_guards_constant_truth():
    m = regression_metrics([1, 2, 3, 4], [4, 3, 2, 1])
    assert m["r2"] < 0 and np.isclose(m["rmse"] ** 2, m["mse"])
    assert np.isnan(regression_metrics([1, 1, 1], [1, 2, 3])["r2"])


def test_baseline_forecasts_use_history_only():
    b = rf.baseline_forecasts(np.array([1.0, np.nan, 3.0]), 3)
    assert (b["persistence"] == 3.0).all() and np.isclose(b["mean_last7"][0], 2.0)


def test_real_sarimax_if_available():
    require_module("statsmodels")
    s, d = _series(400)
    out = rf.forecast_district(s, d, {**_fc(), "validation_origin_start": "2020-11-01", "validation_origin_end": "2020-11-15",
                                      "test_origin_start": "2020-11-16", "test_origin_end": "2020-11-30"}, len(s) - 1)
    assert out["status"] in ("ok", "unavailable")
    if out["status"] == "ok":
        assert len(out["forecast"]) == 3 and min(out["forecast"]) >= 0
