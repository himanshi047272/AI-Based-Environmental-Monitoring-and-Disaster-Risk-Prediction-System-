import json
import tempfile
from pathlib import Path

import pandas as pd

from src import geospatial_mapping as gm
from src.utils import require_module


def _gj():
    sq = lambda x, y: [[[x, y], [x + 1, y], [x + 1, y + 1], [x, y + 1], [x, y]]]  # noqa: E731
    return {"type": "FeatureCollection", "features": [
        {"type": "Feature", "properties": {"lgd": "101", "name": "A"}, "geometry": {"type": "Polygon", "coordinates": sq(70, 20)}},
        {"type": "Feature", "properties": {"lgd": 102, "name": "B"}, "geometry": {"type": "Polygon", "coordinates": sq(72, 20)}},
        {"type": "Feature", "properties": {"lgd": None, "name": "C"}, "geometry": {"type": "Polygon", "coordinates": sq(74, 20)}},
        {"type": "Feature", "properties": {"lgd": 999, "name": "orphan"}, "geometry": {"type": "MultiPolygon", "coordinates": [sq(76, 20)]}}]}


def _write(obj):
    p = Path(tempfile.mkdtemp()) / "g.geojson"
    p.write_text(json.dumps(obj))
    return p


def test_geojson_load_and_join_report_by_code():
    gj, st = gm.load_geojson(_write(_gj()), "lgd")
    assert st["ok"] and st["features_without_code"] == 1
    rep = gm.join_report(gj, [101, 102, 103])
    assert rep["matched"] == 2 and rep["districts_without_geometry"] == [103] and rep["geometries_without_data"] == [999]


def test_missing_or_wrong_property_reported_not_crashed():
    assert not gm.load_geojson("/nonexistent/x.geojson", "lgd")[0] and not gm.load_geojson(_write(_gj()), "wrong_prop")[0]
    bad = Path(tempfile.mkdtemp()) / "b.geojson"; bad.write_text("{not json")
    assert gm.load_geojson(bad, "lgd")[1]["ok"] is False


def test_centroids_and_map_center():
    gj, _ = gm.load_geojson(_write(_gj()), "lgd")
    c = gm.feature_centroids(gj)
    assert abs(c[101][0] - 20.5) < 1e-6 and abs(c[101][1] - 70.5) < 1e-6 and 999 in c
    lat, lon = gm.bounds_center(gj)
    assert 20 < lat < 21 and 70 < lon < 78


def test_map_builds_with_unavailable_district_in_grey():
    require_module("plotly")
    gj, _ = gm.load_geojson(_write(_gj()), "lgd")
    df = pd.DataFrame({"district_code": [101, 102], "district_name": ["A", "B"], "risk_category": ["High", "Unavailable"]})
    fig = gm.build_risk_map(gj, df, 101)
    names = [t.name for t in fig.data if t.name]
    assert "High" in names and "Unavailable" in names
