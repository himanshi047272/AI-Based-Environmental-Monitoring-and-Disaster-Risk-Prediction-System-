# EcoShieldAI — District-Level Flood Risk Monitoring (India)

Flood-risk classifier + ARIMA/SARIMA rainfall forecasts + a Streamlit dashboard, built from two files:
`daily-rainfall-data-district-level.csv` (IMD district daily rainfall, 2009-01-01 → 2024-07-31) and
`India_Flood_Inventory_v3.csv` (recorded flood events, last onset 2023-09-10).

> **Read this first — what is real, historical, and unavailable**
>
> | Item | Status |
> |---|---|
> | Flood classifier, labels, features, metrics | **Real, trained on your CSVs** (see `outputs/reports`, `models/<version>/`) |
> | Dashboard predictions | **Historical.** Computed from archived rainfall as of the latest feasible date (≈ 2024-03-20, because `actual` rainfall is empty after ~March 2024). They are **not** current forecasts. |
> | ARIMA / SARIMA rainfall forecasts | Code complete; needs `statsmodels` (`pip install -r requirements.txt`) then `python -m src.pipeline forecast`. Until then the dashboard says forecasts are unavailable. |
> | Live data | **Off by default.** Open-Meteo adapter is implemented but must be enabled and its terms/coverage verified by you. Live mode shows rainfall only. |
> | District map | **Needs a boundary GeoJSON with LGD codes that you supply** (none is bundled; see below). Without it the dashboard shows a state-level fallback and says so. |

## Quick start (Windows PowerShell)

```powershell
cd EcoShieldAI
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# 1. put the ORIGINAL csv files in data\raw\  (they are only ever read)
# 2. pipeline
python -m src.pipeline prepare      # audit, clean, match districts, labels, features   (~1 min)
python -m src.pipeline train        # compare models, save versioned artefacts          (~7 min on 1 CPU)
python -m src.pipeline forecast     # ARIMA/SARIMA rainfall forecasts (needs statsmodels; slow, see below)
python -m src.pipeline predict      # score districts with the saved production model
streamlit run app.py
python -m tests.run_tests           # or: pytest
```
`python -m src.pipeline all` runs the four stages; `train --quick` is a smoke test on ~12 % of districts.
`forecast --max-districts 20` limits runtime while testing (full run ≈ hours on one core; set `forecast.n_jobs`).

## What the pipeline does

1. **Audit/clean** (`data_loader`, `data_cleaning`) – encoding/malformed-row detection, date-format discovery, invalid
   rainfall → `NaN` (never 0), duplicate handling, insufficient-history list. Reports: `outputs/reports/data_quality_report.{md,json}`.
2. **District matching** (`district_matching`) – LGD code first, validated against the rainfall master **and** the event's
   state codes; exact normalised-name fallback only inside the event's states; ambiguous/invalid never forced.
   Report: `district_mapping_report.json`, `district_mapping_detail.csv`.
   Findings on your data: district code **9 (Leh Ladakh) is shared by two entities → excluded**; 97 inventory codes are not
   in the rainfall data; 1,362 code/state mismatches rejected.
3. **Labels** (`label_generation`) – documented in the module docstring. `label_h = 1` iff a recorded flood-episode *onset*
   falls in days *t+1…t+h* (h = 1, 2, 3). Overlapping/adjacent events merge into one episode; in-event days, unknown-label
   tail (after the inventory ends), low-coverage states and short-history districts are excluded. **A day without a record is
   not a confirmed flood-free day.** Reports: label positive rates by year/month/state/district, inventory coverage tables.
4. **Features** (`feature_engineering`) – calendar-correct lags on a dense daily grid, rolling sum/mean/max, wet-day counts,
   trends, same-day state-level rainfall context, seasonality, normal-rainfall anomaly, plus district statistics fitted on
   **training rows only**. `rfs` is **not used** (meaning undocumented). `deviation` is derived from `actual` and unused.
5. **Selection / split / imbalance / models** (`feature_selection`, `train_models`) – 70/15/15 chronological split with a 3-day
   purge; selection on training data only; class-weighting vs random oversampling vs SMOTE compared on validation (SMOTE is
   implemented in-house, applied after imputation/scaling to training data only, with the binary monsoon flag copied rather
   than interpolated); Logistic Regression, Random Forest, Extra Trees, HistGradientBoosting, GradientBoosting (+XGBoost/LightGBM
   automatically if installed); baselines (always-negative, 3-day-rainfall rule, district flood rate). Threshold chosen on
   validation (max F1; `min_recall` mode available). Separate saved models for 1-, 2-, 3-day horizons.
6. **Metrics** (`evaluate_models`) – classifier: ROC-AUC, accuracy, precision, recall, confusion matrix. Rainfall forecasts:
   RMSE, MSE, R² (R² can be negative). No regression metrics on binary labels.
7. **Rainfall forecasting** (`rainfall_forecasting`) – per-district ARIMA/SARIMA (SARIMAX) on sqrt-rainfall with NaN gaps kept,
   order/seasonality tuned on June-2023 origins, reported on Jul–Sep-2023 origins vs persistence and 7-day-mean baselines.
   Seasonality is only tried when the series' ACF at the candidate period is significant. Short/gappy/non-converging districts →
   `unavailable`. **ARIMA/SARIMA forecast rain, not floods.** The classifier uses *observed* rainfall features only, so forecast
   values are never fed into the wrong columns; forecast and risk are displayed separately.
8. **Artefacts** – `models/vYYYYmmdd_HHMMSS/h{1,2,3}/{model.joblib, district_stats.joblib, meta.json}` plus comparison
   CSVs and `training_report.json`. A new run never overwrites an old one; `models/LATEST` is written last.

## Risk categories

Low / Moderate / High / Very high = quantile bands (0.90 / 0.97 / 0.995, `config/settings.yaml → risk_categories`) of
validation-set scores. They rank relative risk; scores are **uncalibrated** (training re-weighted classes) and the bands are **not**
scientifically validated warning levels. Districts without a reliable prediction are grey “Unavailable”, never “Low”.

## District boundaries (you must supply)

No boundary file was available offline and I could not verify any source's licence or identifiers, so none is bundled.
1. Obtain a district GeoJSON whose features carry the **LGD district code** (or build a crosswalk if it uses Census-2011 codes —
   a wrong crosswalk silently mislabels districts). Check its licence.
2. Save as `data/raw/geo/india_districts.geojson` and set `paths.geojson_code_property` to the property name.
3. The dashboard reports joined / missing-geometry / orphan-geometry counts. Rainfall data has 627 usable districts; boundaries
   created after the LGD snapshot behind your data may not match — they are reported, not forced.

## Live data

`live.enabled: false` by default. To try it: verify the provider's terms, coverage and units; set `live.enabled: true`; put any key
in the environment variable `OPEN_METEO_API_KEY` or `.streamlit/secrets.toml` (never in code). The adapter fetches daily
precipitation at district centroids with timeouts, retries, 429 back-off, unit/shape validation, a TTL cache and stale-cache
fallback; every result carries source, retrieval time, latest observation date and age. It is **gridded model/analysis rainfall,
not IMD gauge data**, so the classifier is deliberately *not* applied to it: Live mode shows live rainfall while risk scores remain
historical (and the banner says so). Any failure → Historical/Demo mode.

## Streamlit Community Cloud

Raw CSVs (280 MB) don't belong in git. Run the pipeline locally, then commit only what the app reads: `outputs/predictions/*`,
`outputs/forecasts/*`, `outputs/reports/*`, `models/LATEST` and the latest `models/<version>/` (check file sizes; the Extra-Trees
`model.joblib` files can be large—the dashboard only needs `meta.json` and the CSVs, so you may omit the `.joblib` files for
deployment), the GeoJSON (if its licence allows), `app.py`, `src/`, `config/`, `requirements.txt`. Add secrets in the Cloud UI.

## Tests

`python -m tests.run_tests` (or `pytest`): cleaning, matching, labels/horizon, calendar lags, no-future-leakage, chronological split,
training-only resampling, reproducible features, forecasting workflow (stub fitter + real SARIMAX when installed), classifier input
validation, map join, live-provider failure modes, CSV export, and a headless dashboard start-up test (`streamlit.testing`) that checks
no retraining happens.

## Known limitations

* Rainfall is the only driver (no terrain, soil moisture, river gauges, dams).
* Labels are patchy: inventory reporting intensity changes over time (2022 surge falls in the test period), 7 states have almost no records.
* Skill is modest — see `model_comparison_with_baselines.csv`; extreme class imbalance (~0.5 % positives) keeps precision/recall low.
* Inventory events with up to 259 districts (and some 365-day entries) are noisy; the in-event mask is capped at 30 days.
* Snapshots are historical; `actual` rainfall in the archive stops ≈ March 2024.
